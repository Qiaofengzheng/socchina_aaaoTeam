/*************************************
 * ����PA5ʹLED��ƽ��ת
 */

#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/touchkey.h"

void LED_Init(void);

u16 adc_val;

void System_Init()
{
    LED_Init();
    Touch_Key_Init();
}

void System_Loop()
{
    adc_val = Touch_Key_Adc(ADC_Channel_5);
    printf("TouckKey Value:%d\r\n", adc_val);
    if(adc_val < 3000)GPIO_TogglePin(GPIOE, GPIO_Pin_0);
    Delay_Ms(200);
}

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
}
