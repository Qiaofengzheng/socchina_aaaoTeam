#include "debug.h"
#include "../General_Files/drivers/touchkey.h"

void Touch_Key_Init(void)
{
//===============================����ʼ����=============================
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    ADC_InitTypeDef  ADC_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div8);

    GPIO_InitStructure.GPIO_Pin = TOUCH_KEY_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);

    ADC_Cmd(ADC1, ENABLE);
    TKey1->CTLR1 |= (1 << 26) | (1 << 24); // Enable TouchKey and Buffer
}

unsigned int Touch_Key_Adc(unsigned char ch)
{
//=============================����ȡ����ADCֵ��=============================
//������ADCͨ������ΧADC_Channel_x������x = 0-15
//����ֵ����ȡ����ADCֵ����Χ0-4095
    ADC_RegularChannelConfig(ADC1, ch, 1, ADC_SampleTime_13Cycles5);
    TKey1->IDATAR1 = 0x07; //Charging Time
    TKey1->RDATAR = TKey1->IDATAR1;   //Discharging Time
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
    return (uint16_t)TKey1->RDATAR;
}
