#ifndef __TOUCH_KEY_H
#define __TOUCH_KEY_H

#define TOUCH_KEY_PIN GPIO_Pin_5

void Touch_Key_Init(void);
unsigned int Touch_Key_Adc(unsigned char ch);

#endif
