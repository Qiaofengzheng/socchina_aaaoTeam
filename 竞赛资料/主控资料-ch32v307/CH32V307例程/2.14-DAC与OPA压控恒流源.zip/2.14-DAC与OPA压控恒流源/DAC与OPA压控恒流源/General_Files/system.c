#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/dac_drv.h"
#include "../General_Files/drivers/OPA.h"
#include "../General_Files/drivers/ST7789.h"

uint16_t voltage = 100;//�����ѹ

void System_Init()
{
    ST7789_Init();
    DAC_User_Init();
    OPA4_Init();
}

void System_Loop()
{
    DAC_User_Set_Voltage(DAC1, voltage);

    ST7789_ShowCHN(0, 32, "���������", color_WHITE, color_BLACK, SIZE_CHN_32x32);
    ST7789_ShowNumf(160, 32, voltage/47.22f, 4, color_WHITE, color_BLUE, SIZE_ASCII_16x32);
    ST7789_ShowString(240, 32, "mA", color_WHITE, color_BLACK, SIZE_ASCII_16x32);

    while(1);
}
