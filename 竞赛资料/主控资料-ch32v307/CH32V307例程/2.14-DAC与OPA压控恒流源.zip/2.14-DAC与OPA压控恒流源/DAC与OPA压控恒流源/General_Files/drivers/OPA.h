#ifndef __OPA_H
#define __OPA_H

#define OPA4_PORT GPIOB
#define OPA4_CH0P_Pin GPIO_Pin_12
#define OPA4_CH0N_Pin GPIO_Pin_1

void OPA4_Init(void);

#endif /* __OPA_H */
