#include "debug.h"
#include "ch32v30x_opa.h"
#include "../General_Files/drivers/OPA.h"

void OPA4_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    OPA_InitTypeDef  OPA_InitStructure={0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE );

    GPIO_InitStructure.GPIO_Pin = OPA4_CH0P_Pin | OPA4_CH0N_Pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OPA4_PORT, &GPIO_InitStructure);

    OPA_InitStructure.OPA_NUM = OPA4;
    OPA_InitStructure.PSEL = CHP0;
    OPA_InitStructure.NSEL = CHN0;
    OPA_InitStructure.Mode = OUT_IO_ADC;
    OPA_Init(&OPA_InitStructure);
    OPA_Cmd(OPA4, ENABLE);
}
