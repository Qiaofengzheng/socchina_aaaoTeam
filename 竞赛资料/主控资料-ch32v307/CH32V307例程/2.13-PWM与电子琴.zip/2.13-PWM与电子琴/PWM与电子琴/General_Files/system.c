#include "system.h"
#include "debug.h"
#include "../General_Files/apps/music.h"

//extern const unsigned int QiLiXiang[60][2];

const unsigned int YYDJTC[][2] =
{
        {midi_la, beat},{midi_so, beat + beat1_2},{midi_mi, beat1_2},{midi_mi, beat},{midi_do, beat},//65331
        {midi_re, beat + beat1_2},{midi_do, beat1_2},{midi_re, beat},{midi_mi, beat},//2123
        {midi_do, beat + beat1_2},{midi__la, beat1_2},{midi__la, beat},{midi__so, beat},//1665
        {midi_do, beat * 2},{midi_o, beat},
        {midi__so, beat},{midi_do, beat + beat1_2},{midi_do, beat1_2},{midi_do, beat},{midi_mi, beat},//51113
        {midi_re, beat + beat1_2},{midi_do, beat1_2},{midi_re, beat},{midi_mi, beat},//2123
        {midi_do, beat + beat1_2},{midi_do, beat1_2},{midi_mi, beat},{midi_so, beat},//1135
        {midi_la, beat * 2},{midi_o, beat},{midi_la, beat},//6-06
        {midi_so, beat + beat1_2},{midi_mi, beat1_2},{midi_mi, beat},{midi_do, beat},//5331
        {midi_re, beat + beat1_2},{midi_do, beat1_2},{midi_re, beat},{midi_mi, beat},//2123
        {midi_do, beat + beat1_2},{midi__la, beat1_2},{midi__la, beat},{midi__so, beat},//1665
        {midi_do, beat * 2},{midi_o, beat},{midi_la, beat},//1-06
        {midi_so, beat + beat1_2},{midi_mi, beat1_2},{midi_mi, beat},{midi_do, beat},//5331
        {midi_re, beat + beat1_2},{midi_do, beat1_2},{midi_re, beat},{midi_la, beat},//2126
        {midi_so, beat + beat1_2},{midi_mi, beat1_2},{midi_mi, beat},{midi_so, beat},//5335
        {midi_la, beat * 2},{midi_o, beat},{midi_do_, beat},//6-01
        {midi_so, beat + beat1_2},{midi_mi, beat1_2},{midi_mi, beat},{midi_do, beat},//5331
        {midi_re, beat + beat1_2},{midi_do, beat1_2},{midi_re, beat},{midi_mi, beat},//2123
        {midi_do, beat + beat1_2},{midi__la, beat1_2},{midi__la, beat},{midi__so, beat},//1665
        {midi_do, beat * 3},{midi_o, beat},//1--0
};

void System_Init()
{
    Music_Init();
}

void System_Loop()
{
    Midi_Play(YYDJTC, sizeof(YYDJTC)/sizeof(YYDJTC[0]));
}
