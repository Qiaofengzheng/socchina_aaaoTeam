#ifndef __MUSIC_H
#define __MUSIC_H

#define PWM_PORT GPIOE
#define PWM_PIN GPIO_Pin_4

enum
{
    midi_o = 0,
    midi__do = 262,
    midi__re = 294,
    midi__mi = 330,
    midi__fa = 349,
    midi__so = 392,
    midi__la = 440,
    midi__si = 494,
    midi_do = 523,
    midi_re = 587,
    midi_mi = 659,
    midi_fa = 698,
    midi_so = 784,
    midi_la = 880,
    midi_si = 988,
    midi_do_ = 1046,
    midi_re_ = 1175,
    midi_mi_ = 1318,
    midi_fa_ = 1397,
    midi_so_ = 1568,
    midi_la_ = 1760,
    midi_si_ = 1976,
}midi_t;

enum
{
    beat = (60*1000)/77,
    beat1_2 = beat/2,
    beat1_4 = beat/4,
    beat1_8 = beat/8,
    beat1_16 = beat/16,
}beat_t;

void Music_Init();
void Midi_Play(const unsigned int music[][2], unsigned int length);

#endif /* __MUSIC_H */
