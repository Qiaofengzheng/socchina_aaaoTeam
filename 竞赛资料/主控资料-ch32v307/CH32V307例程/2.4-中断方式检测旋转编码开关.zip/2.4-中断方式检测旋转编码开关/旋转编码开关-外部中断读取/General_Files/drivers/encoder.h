#ifndef __ENCODER_H
#define __ENCODER_H

#define ENCODER_A_READ GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_4)
#define ENCODER_B_READ GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_5)
#define ENCODER_SW_READ GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3)

typedef struct 
{
    uint8_t IT_flag;
    void (*Add)(void);
    void (*Minus)(void);
    void (*Enter)(void);
    void (*Init)(void);
}encoder_t;

extern encoder_t encoder;

#endif

  
