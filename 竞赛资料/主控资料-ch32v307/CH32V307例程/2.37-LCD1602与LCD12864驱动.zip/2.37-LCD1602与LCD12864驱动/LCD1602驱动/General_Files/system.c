#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/LCD1602.h"

void System_Init()
{
    LCD1602_Init();
    LCD1602_Display_EN(LCD1602_DIS_ON, LCD1602_CURSOR_ON, LCD1602_CURSOR_R_ON);
    LCD1602_ShowStr(0, 0, "Hello");
    LCD1602_ShowNumf(6, 0, -3.14159, 1, 5);
    LCD1602_Pos(0, 1);
    LCD1602_ShowChar(0);
    LCD1602_ShowChar(1);
    LCD1602_ShowChar(2);
}

void System_Loop()
{
    static unsigned int i = 0;
    LCD1602_ShowNum(10, 1, i, 3);
    LCD1602_Pos(14, 1);
    LCD1602_ShowChar(i++);
    if(i == 256)i = 0;
    Delay_Ms(400);
}
