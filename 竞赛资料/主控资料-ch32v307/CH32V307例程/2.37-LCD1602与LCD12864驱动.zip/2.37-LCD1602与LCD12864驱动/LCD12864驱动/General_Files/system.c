#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/LCD12864.h"

void System_Init()
{
    ST7920_Init();
    ST7920_Display_EN(ST7920_DIS_ON, ST7920_CURSOR_ON, ST7920_CURSOR_R_ON);
    ST7920_ShowStr(0, 0, "Hello");
    ST7920_ShowStr(3, 0, "���");
    ST7920_ShowNumf(0, 1, -3.14159, 1, 5);
    ST7920_Pos(0, 2);
    ST7920_CGRAM_ShowChar(0);
    ST7920_CGRAM_ShowChar(1);
    ST7920_CGRAM_ShowChar(2);
    ST7920_CGRAM_ShowChar(3);
}

void System_Loop()
{
    static unsigned char i = 2;
    ST7920_ShowNum(10, 1, i, 3);
    ST7920_Pos(15, 1);
    ST7920_ShowChar(i++);
    if(i == 128)i = 0;
    Delay_Ms(500);
}
