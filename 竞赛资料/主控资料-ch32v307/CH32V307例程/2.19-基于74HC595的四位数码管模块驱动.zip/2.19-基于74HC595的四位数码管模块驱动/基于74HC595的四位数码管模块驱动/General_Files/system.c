#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/74HC595.h"

u8 buf[8] = {A, b, C, d, 8, 1, 3, 5};

void System_Init()
{
    _74HC595_Init();
}

void System_Loop()
{
    _74HC595_Display(2, buf);
}
