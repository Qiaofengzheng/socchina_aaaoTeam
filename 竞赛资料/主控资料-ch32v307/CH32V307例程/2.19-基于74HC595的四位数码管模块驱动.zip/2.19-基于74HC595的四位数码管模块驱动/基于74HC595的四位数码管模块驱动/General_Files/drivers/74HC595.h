#ifndef __74HC595_H
#define __74HC595_H

//============================�����Ŷ��塿=================================
#define _74HC595_PORT GPIOC
#define _74HC595_SCLK_PIN		GPIO_Pin_10
#define _74HC595_RCLK_PIN       GPIO_Pin_11
#define _74HC595_DIO_PIN        GPIO_Pin_12

#define _74HC595_SCLK_SET(n) GPIO_WriteBit(_74HC595_PORT, _74HC595_SCLK_PIN, n);
#define _74HC595_RCLK_SET(n) GPIO_WriteBit(_74HC595_PORT, _74HC595_RCLK_PIN, n);
#define _74HC595_DIO_SET(n)  GPIO_WriteBit(_74HC595_PORT, _74HC595_DIO_PIN, n);

enum//��ģ
{
    A = 0x88,
    b = 0x83,
    C = 0xc6,
    d = 0xA1,
    E = 0x86,
    F = 0x8e,
    NC = 0xbf,
    OFF = 0xff,
    point = 0x7f,
};

void _74HC595_Init();
void _74HC595_Display(unsigned char num, unsigned char *_data);

#endif
