#include "system.h"
#include "debug.h"
#include  "../General_Files/drivers/SSD1306.h"
#include "../General_Files/apps/NTC.h"

void System_Init()
{
    SSD1306_Init();
    NTC_Init();
}

void System_Loop()
{
    NTC_Get_Temperature();
    SSD1306_ShowNum(0, 0, NTC_value.adc_val, 4, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowNumf(40, 0, NTC_value.res_val, 4, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(80, 0, "kohm", SSD1306_SIZE_16, SSD1306_PO);

    SSD1306_ShowNumf(0, 2, NTC_value.voltage, 3, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowChar(32, 2, 'v', SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowNum(60, 2, NTC_value.temper, 2, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowCN(84, 2, "��", SSD1306_PO);

    SSD1306_ShowStr(0, 4, "Temper_int:", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowNum(96, 4, TempSensor_Volt_To_Temper(NTC_Get_ADC_Average(ADC_Channel_TempSensor, 50) * VREF * 1000 / 4095), 2, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowCN(112, 4, "��", SSD1306_PO);

    SSD1306_ShowStr(0, 6, "Vref_int:", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowNumf(80, 6, NTC_Get_ADC_Average(ADC_Channel_Vrefint, 50) * VREF / 4095, 3, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowChar(112, 6, 'v', SSD1306_SIZE_16, SSD1306_PO);
    Delay_Ms(100);
}
