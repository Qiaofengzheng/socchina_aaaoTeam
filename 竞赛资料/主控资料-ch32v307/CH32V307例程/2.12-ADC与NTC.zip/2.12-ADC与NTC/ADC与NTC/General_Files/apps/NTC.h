#ifndef __NTC_H
#define __NTC_H

#define NTC_PORT GPIOA
#define NTC_PIN GPIO_Pin_7

#define VREF 2.51f

typedef struct
{
    unsigned int adc_val;
    char temper;
    float voltage;
    float res_val;
}NTC_value_t;

void NTC_Init();
unsigned int NTC_Get_ADC_Val(unsigned char ch);
unsigned int NTC_Get_ADC_Average(unsigned char ch, unsigned char times);
void NTC_Get_Temperature();

extern NTC_value_t NTC_value;

#endif /* __NTC_H */
