#include "system.h"
#include "debug.h"

#define  GLOBAL_DELAY 200

void System_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_WriteBit(GPIOE, GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6, Bit_SET);
}

void System_Loop()
{
    GPIO_WriteBit(GPIOE, GPIO_Pin_0, Bit_RESET);
    GPIO_WriteBit(GPIOE, GPIO_Pin_5 | GPIO_Pin_6, Bit_SET);
    Delay_Ms(GLOBAL_DELAY);
    GPIO_WriteBit(GPIOE, GPIO_Pin_5, Bit_RESET);
    GPIO_WriteBit(GPIOE, GPIO_Pin_6 | GPIO_Pin_0, Bit_SET);
    Delay_Ms(GLOBAL_DELAY);
    GPIO_WriteBit(GPIOE, GPIO_Pin_6, Bit_RESET);
    GPIO_WriteBit(GPIOE, GPIO_Pin_0 | GPIO_Pin_5, Bit_SET);
    Delay_Ms(GLOBAL_DELAY);
}
