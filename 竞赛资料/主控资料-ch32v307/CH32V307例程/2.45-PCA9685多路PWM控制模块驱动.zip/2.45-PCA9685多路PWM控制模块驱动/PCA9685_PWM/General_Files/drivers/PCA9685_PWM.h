#ifndef __PCA9685_PWM_H
#define __PCA9685_PWM_H

#define PCA9685_ADDR		(0x40<<1)

#define PCA9685_MODE1 		0x00
#define PCA9685_PRESCALE 	0xFE

#define PCA9685_PWM0_ON_L 	0x06
#define PCA9685_PWM0_ON_H 	0x07
#define PCA9685_PWM0_OFF_L 	0x08
#define PCA9685_PWM0_OFF_H 	0x09

#define PCA9685_ALL_ON_L 	0xFA
#define PCA9685_ALL_ON_H 	0xFB
#define PCA9685_ALL_OFF_L 	0xFC
#define PCA9685_ALL_OFF_H 	0xFD

void PCA9685_PWM_Init();
void PCA9685_PWM_Reset();
void PCA9685_PWM_SetFreq(unsigned int freq);
void PCA9685_PWM_SetPWM(unsigned char channel, unsigned int on, unsigned int off);
void PCA9685_PWM_SetDuty(unsigned char channel, unsigned char duty);
#endif
  
