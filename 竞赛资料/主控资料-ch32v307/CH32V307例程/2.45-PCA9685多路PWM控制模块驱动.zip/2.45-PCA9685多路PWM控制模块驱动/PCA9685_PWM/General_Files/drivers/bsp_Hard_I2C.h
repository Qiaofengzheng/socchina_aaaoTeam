#ifndef __BSP_HARD_I2C_H
#define __BSP_HARD_I2C_H

#define I2C_PORT        GPIOB
#define I2C_SCL_PIN     GPIO_Pin_10
#define I2C_SDA_PIN     GPIO_Pin_11

void BSP_Hard_I2C_Init();
void BSP_Hard_I2C_WriteREG(unsigned char DEV_ADDR, unsigned char REG_ADDR,unsigned char _data);
void BSP_Hard_I2C_Mem_Write(unsigned char DEV_ADDR, unsigned char REG_ADDR, unsigned char len, unsigned char *buf);
void BSP_Hard_I2C_Mem_Read(unsigned char DEV_ADDR, unsigned char len, unsigned char *buf);

#endif
  
