#include "PCA9685_PWM.h"
#include "bsp_Hard_I2C.h"
#include "debug.h"

void PCA9685_PWM_Init()
{
/*************************************����ʼ����******************************************/
	BSP_Hard_I2C_Init();
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_ALL_ON_L, 0);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_ALL_ON_H, 0);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_ALL_OFF_L, 0);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_ALL_OFF_H, 0);
}

void PCA9685_PWM_Reset()
{
/*************************************����λ��******************************************/
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_MODE1, 0x00);
}

void PCA9685_PWM_SetFreq(unsigned int freq)
{
/*************************************������PWMƵ�ʡ�******************************************
 * ����:
 * freq: PWMƵ��
 */
	uint32_t prescale;
	uint8_t oldmode, newmode;
	prescale = (25000000 / 4096.0f / freq) - 1.0f + 0.5f;//25MHzʱ��

	BSP_Hard_I2C_Mem_Write(PCA9685_ADDR, PCA9685_MODE1, 0, NULL);
	BSP_Hard_I2C_Mem_Read(PCA9685_ADDR, 1, &oldmode);
	newmode = (oldmode & 0x7F) | 0x10;							//˯��
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_MODE1, newmode);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PRESCALE, prescale);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_MODE1, oldmode);//�ָ�
	Delay_Ms(2);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_MODE1, oldmode | 0xa1);
}

void PCA9685_PWM_SetPWM(unsigned char channel, unsigned int on, unsigned int off)
{
/*************************************������PWM��******************************************
 * ����:
 * channel: ͨ��
 * on: PWM��ʼλ��(0 - 4095)
 * off: PWM����λ��(0-4095)
 */
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_ON_L + 4 * channel, on);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_ON_H + 4 * channel, on >>8);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_OFF_L + 4 * channel, off);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_OFF_H + 4 * channel, off >> 8);
}

void PCA9685_PWM_SetDuty(unsigned char channel, unsigned char duty)
{
/*************************************������ռ�ձȡ�******************************************
 * ����:
 * channel: ͨ��
 * duty: ռ�ձ�(0 - 100)
 */
	unsigned int temp;
	temp = (4095 * duty / 100.0f) + 0.5f;
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_ON_L + 4 * channel, 0);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_ON_H + 4 * channel, 0);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_OFF_L + 4 * channel, temp);
	BSP_Hard_I2C_WriteREG(PCA9685_ADDR, PCA9685_PWM0_OFF_H + 4 * channel, temp >> 8);
}
