#include "system.h"
#include "debug.h"

#include "PCA9685_PWM.h"

void System_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	PCA9685_PWM_Init();
	PCA9685_PWM_Reset();
	PCA9685_PWM_SetFreq(500);
	PCA9685_PWM_SetPWM(0, 0, 2048);
	PCA9685_PWM_SetPWM(1, 1024, 3072);
	PCA9685_PWM_SetDuty(2, 66);
}

void System_Loop()
{
    GPIO_TogglePin(GPIOE, GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6);
    Delay_Ms(500);
}
