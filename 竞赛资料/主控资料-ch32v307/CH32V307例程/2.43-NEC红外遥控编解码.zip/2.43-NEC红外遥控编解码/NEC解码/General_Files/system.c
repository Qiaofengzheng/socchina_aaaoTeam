#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/NEC_Decode.h"

void System_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_WriteBit(GPIOA, GPIO_Pin_6, RESET);

    NEC_Decode_Init();
}

void System_Loop()
{
	if(NEC_data.flag & NEC_MASK_DECODE_OK)
	{
		NEC_data.flag &= ~NEC_MASK_DECODE_OK;
		printf("Addr: %02X -- Cmd: %02X\r\n", NEC_data.addr, NEC_data.cmd);
	}
	else if(NEC_data.flag & NEC_MASK_REPEAT)
	{
		NEC_data.flag &= ~NEC_MASK_REPEAT;
		printf("Repeat...\r\n");
	}
}
