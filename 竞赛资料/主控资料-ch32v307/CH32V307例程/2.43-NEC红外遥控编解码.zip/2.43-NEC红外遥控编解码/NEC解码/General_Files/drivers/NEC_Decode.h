#ifndef __NEC_DECODE_H
#define __NEC_DECODE_H

//============================�����Ŷ��塿=================================
#define NEC_PORT    GPIOA
#define NEC_RX_PIN 	GPIO_Pin_1

#define NEC_MASK_DECODE_OK	0x80
#define NEC_MASK_REPEAT		0x40

typedef struct
{
	unsigned char flag;
	unsigned char addr;
	unsigned char cmd;
}NEC_data_t;

void NEC_Decode_Init();

extern NEC_data_t NEC_data;

#endif
  
