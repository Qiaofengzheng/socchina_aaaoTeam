#include "debug.h"
#include "NEC_Decode.h"

NEC_data_t NEC_data = {0};

static volatile uint8_t IC_FLAG = 0x00;		//��־λ
static volatile uint8_t NEC_RX_cnt = 0;		//���ռ���
static volatile uint16_t NEC_RX_data[67] = {0};//��ƽʱ�仺��

void NEC_Decode_Init()
{
//=============================����ʼ����=================================
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    TIM_TimeBaseInitTypeDef TIM_InitStructure = {0};
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = NEC_RX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(NEC_PORT, &GPIO_InitStructure);

    TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_InitStructure.TIM_Period = 65535;
    TIM_InitStructure.TIM_Prescaler = (SystemCoreClock / 1000000 - 1);
    TIM_TimeBaseInit(TIM5, &TIM_InitStructure);

    TIM_Cmd(TIM5, ENABLE );

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource1);
    EXTI_InitStructure.EXTI_Line = EXTI_Line1;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;//�����ش����ⲿ�ж�
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

static void NEC_Decode()
{
	uint8_t var, verify = 0;
	for(var = 0; var < 8; ++var)
	{
		NEC_data.addr >>= 1;
		if(NEC_RX_data[3 + var * 2] > 1500 && NEC_RX_data[3 + var * 2] < 1900)
			NEC_data.addr |= 0x80;
	}
	for(var = 0; var < 8; ++var)
	{
		verify >>= 1;
		if(NEC_RX_data[19 + var * 2] > 1500 && NEC_RX_data[19 + var * 2] < 1900)
			verify |= 0x80;
	}
	//��ַУ��
	if(NEC_data.addr != (u8)(~verify))verify = 1;
	else verify = 0;

	for(var = 0; var < 8; ++var)
	{
		NEC_data.cmd >>= 1;
		if(NEC_RX_data[35 + var * 2] > 1500 && NEC_RX_data[35 + var * 2] < 1900)
			NEC_data.cmd |= 0x80;
	}
	for(var = 0; var < 8; ++var)
	{
		verify >>= 1;
		if(NEC_RX_data[51 + var * 2] > 1500 && NEC_RX_data[51 + var * 2] < 1900)
			verify |= 0x80;
	}
	//����У��
	if(NEC_data.cmd != (u8)(~verify))verify = 1;
	else verify = 0;

	if(!verify)NEC_data.flag |= NEC_MASK_DECODE_OK;
}

__attribute__((interrupt("WCH-Interrupt-fast")))
void EXTI1_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line1) == SET)
    {
    	if((IC_FLAG & 0x80) == 0)//������һ������
    	{
    		IC_FLAG |= 0x80;
    		NEC_RX_cnt = 0;
    	}
    	else
    	{
    		NEC_RX_data[NEC_RX_cnt] = TIM5->CNT;
    		NEC_RX_cnt++;

    		if(NEC_RX_cnt >= 3)//��������������ظ���,�����ظ����ֹͣλ
    		{
    			if(NEC_RX_data[0] > 8500 && NEC_RX_data[0] < 12000)//9ms��0.5ms
    			{
					if(NEC_RX_data[1] > 4000 && NEC_RX_data[1] < 5000)//+4.5ms��0.5ms������
					{
						if(NEC_RX_cnt >= 67)
						{
							NEC_Decode();
							IC_FLAG = 0;
						}
					}
					else if(NEC_RX_data[1] > 1500 && NEC_RX_data[1] < 2500)//+2ms��0.5ms�ظ���
					{
						NEC_data.flag |= NEC_MASK_REPEAT;
						IC_FLAG = 0;
					}
					else//ɶҲ����
					{
						NEC_RX_cnt = 0;
					}
    			}
				else//ɶҲ����
				{
					NEC_RX_cnt = 0;
				}
    		}
    	}

    	TIM5->CNT = 0;
    	EXTI_ClearITPendingBit(EXTI_Line1);
    }
}
