#ifndef __NEC_CODE_H
#define __NEC_CODE_H

//============================�����Ŷ��塿=================================
#define NEC_PORT    GPIOA
#define NEC_TX_PIN 	GPIO_Pin_1

void NEC_Code_Init();
void NEC_Send(unsigned char addr, unsigned char cmd);
void NEC_Stop();

#endif
  
