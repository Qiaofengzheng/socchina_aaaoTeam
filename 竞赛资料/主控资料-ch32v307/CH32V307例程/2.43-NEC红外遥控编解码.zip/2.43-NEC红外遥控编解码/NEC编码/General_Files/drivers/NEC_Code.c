#include "debug.h"
#include "NEC_Code.h"

#define NEC_BIT_TIM		(43)
#define NEC_BIT_START	(515)
#define NEC_BIT_STOP	(NEC_BIT_START+21)

static volatile uint32_t NEC_time;	//��ʱ��
static volatile uint8_t NEC_data_cnt;//������
static volatile uint32_t OC_FLAG;	//״̬����־λ

static uint8_t NEC_addr, NEC_cmd;

void NEC_Code_Init()
{
/* =============================����ʼ����================================ */
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    TIM_TimeBaseInitTypeDef TIM_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = NEC_TX_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(NEC_PORT, &GPIO_InitStructure);

    TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_InitStructure.TIM_Prescaler = 72 - 1;//1MHz
    TIM_InitStructure.TIM_Period = 2 - 1;//500kHz
    TIM_TimeBaseInit(TIM5, &TIM_InitStructure);

    TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void NEC_Send(unsigned char addr, unsigned char cmd)
{
/* =============================���������ݡ�================================
 * ����һ�����ݣ�Ȼ�󲻶Ϸ����ظ���
 * ����:
 * addr: ��ַ
 * cmd: ����
 */
	NEC_addr = addr;
	NEC_cmd = cmd;
	//��λ��־λ
	NEC_time = 0;
	NEC_data_cnt = 0;
	OC_FLAG = 0x00000001;
	//��ʼ����
	TIM_Cmd(TIM5, ENABLE);
}

void NEC_Stop()
{
/* =============================��ֹͣ���͡�================================ */
	//ֹͣ����
	TIM_Cmd(TIM5, DISABLE);
	//��λ��־λ
	NEC_time = 0;
	NEC_data_cnt = 0;
	OC_FLAG = 0x00000001;
}

static inline void NEC_Code()
{
	switch(OC_FLAG & 0x7FFFFFFF)
	{
		//Leader
		case 0x00000001:
		{
			if(NEC_time == 4500)//9ms
			{
				OC_FLAG |= 0x80000000;//�͵�ƽ
			}
			if(NEC_time == 6750)//4.5ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;//״̬����ת
				NEC_time = 0;
			}
			break;
		}
		//addr
		case 0x00000002:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x01)) || ((NEC_time == 562) && ((NEC_addr & 0x01) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000004:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x02)) || ((NEC_time == 562) && ((NEC_addr & 0x02) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000008:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x04)) || ((NEC_time == 562) && ((NEC_addr & 0x04) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000010:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x08)) || ((NEC_time == 562) && ((NEC_addr & 0x08) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000020:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x10)) || ((NEC_time == 562) && ((NEC_addr & 0x10) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000040:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x20)) || ((NEC_time == 562) && ((NEC_addr & 0x20) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000080:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x40)) || ((NEC_time == 562) && ((NEC_addr & 0x40) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000100:
		{
			if(((NEC_time == 1125) && (NEC_addr & 0x80)) || ((NEC_time == 562) && ((NEC_addr & 0x80) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				if(NEC_data_cnt == 0)
				{
					NEC_addr = (u8)(~NEC_addr);
					OC_FLAG = 0x00000002;
					NEC_data_cnt++;
				}
				else
				{
					OC_FLAG = 0x00000200;
					NEC_data_cnt = 0;
				}
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		//cmd
		case 0x00000200:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x01)) || ((NEC_time == 562) && ((NEC_cmd & 0x01) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000400:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x02)) || ((NEC_time == 562) && ((NEC_cmd & 0x02) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00000800:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x04)) || ((NEC_time == 562) && ((NEC_cmd & 0x04) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00001000:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x08)) || ((NEC_time == 562) && ((NEC_cmd & 0x08) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00002000:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x10)) || ((NEC_time == 562) && ((NEC_cmd & 0x10) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00004000:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x20)) || ((NEC_time == 562) && ((NEC_cmd & 0x20) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00008000:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x40)) || ((NEC_time == 562) && ((NEC_cmd & 0x40) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00010000:
		{
			if(((NEC_time == 1125) && (NEC_cmd & 0x80)) || ((NEC_time == 562) && ((NEC_cmd & 0x80) == 0)))//1.6875/0.5625ms
			{
				OC_FLAG = (OC_FLAG & 0x7FFFFFFF) << 1;
				if(NEC_data_cnt == 0)
				{
					NEC_cmd = (u8)(~NEC_cmd);
					OC_FLAG = 0x00000200;
					NEC_data_cnt++;
				}
				else
				{
					OC_FLAG = 0x00020000;
					NEC_data_cnt = 0;
				}
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		//stop
		case 0x00020000:
		{
			if(NEC_time == 562)//562us
			{
				OC_FLAG = 0x00040000;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		//Repeat
		case 0x00040000:
		{
			OC_FLAG |= 0x80000000;
			if(NEC_time == 55000)//110ms
			{
				OC_FLAG = 0x00080000;
				NEC_time = 0;
			}
			break;
		}
		case 0x00080000:
		{
			if(NEC_time == 5563)//2.125ms
			{
				OC_FLAG = 0x00100000;
				NEC_time = 0;
			}
			else if(NEC_time == 4500)//9ms
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		case 0x00100000:
		{
			if(NEC_time == 562)//562us
			{
				OC_FLAG = 0x00040000;
				NEC_time = 0;
			}
			else if(NEC_time == 281)//562us
			{
				OC_FLAG |= 0x80000000;
			}
			break;
		}
		default: break;
	}
}

static uint8_t i = 0;

__attribute__((interrupt("WCH-Interrupt-fast")))
void TIM5_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM5, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
		NEC_time++;
		//NEC����
		NEC_Code();

		//����38kHz�ز�
		if(++i >= 13)
		{
			i = 0;//38.46kHz
		}
		if(i >= 4 || (OC_FLAG & 0x80000000))GPIO_WriteBit(NEC_PORT, NEC_TX_PIN, Bit_RESET);//30%ռ�ձ�
		else GPIO_WriteBit(NEC_PORT, NEC_TX_PIN, Bit_SET);
	}
}
