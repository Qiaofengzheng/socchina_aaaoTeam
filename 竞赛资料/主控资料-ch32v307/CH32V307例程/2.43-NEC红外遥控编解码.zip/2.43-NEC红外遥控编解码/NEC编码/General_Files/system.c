#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/NEC_Code.h"

void System_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_WriteBit(GPIOA, GPIO_Pin_6, RESET);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

    NEC_Code_Init();
}

void System_Loop()
{
	if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3) == RESET)
	{
		Delay_Ms(10);
		if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3) == RESET)
		{
			NEC_Send(0xC1, 0x45);
			while(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3) == RESET);
		}
	}
	NEC_Stop();
//	NEC_SendRepeat();
//	Delay_Ms(110);
}
