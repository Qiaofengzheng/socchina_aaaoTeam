#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/WS2812_SPI_drv.h"

unsigned long color1[WS2812_NUM]=
{
        0xff0000,
        0x00ff00,
        0x0000ff,
        0xffff00,
};
unsigned long color2[WS2812_NUM]=
{
        0x00ff00,
        0x0000ff,
        0xff0000,
        0x00ffff,
};
unsigned long color3[WS2812_NUM]=
{
        0x0000ff,
        0xff0000,
        0x00ff00,
        0xffff00,
};
unsigned long color4[WS2812_NUM]=
{
        0xffffff,
        0xffffff,
        0xffffff,
        0xffffff,
};

void System_Init()
{
    WS2812_Init();
}

void System_Loop()
{
    WS2812_SendData(color1);
    Delay_Ms(500);
    WS2812_SendData(color2);
    Delay_Ms(500);
    WS2812_SendData(color3);
    Delay_Ms(500);
    WS2812_SendData(color4);
    Delay_Ms(500);
}
