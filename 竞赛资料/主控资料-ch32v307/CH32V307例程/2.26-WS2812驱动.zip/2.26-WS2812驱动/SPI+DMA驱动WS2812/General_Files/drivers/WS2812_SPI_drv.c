#include "WS2812_SPI_drv.h"
#include "debug.h"

#define TIMING_1    0xFFE0//1111 1111 1110 0000,duty = 69����0.85/1.25 = 68��
#define TIMING_0    0xF800//1111 1000 0000 0000,duty = 31����0.4/1.25 = 32��

void WS2812_Init()
{
/*========================================����ʼ����=======================================*/
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    SPI_InitTypeDef SPI_InitStructure={0};
    DMA_InitTypeDef DMA_InitStructure = {0};

    RCC_AHBPeriphClockCmd( RCC_AHBPeriph_DMA2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3, ENABLE);

    GPIO_InitStructure.GPIO_Pin = WS2812_PIN | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(WS2812_PORT, &GPIO_InitStructure);

    SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;//96/2/4 = 12MHz, 1/12MHz*16bit = 1.3us = 770kHz
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init( SPI3, &SPI_InitStructure );
    SPI_Cmd( SPI3, ENABLE );

    DMA_DeInit(DMA2_Channel2);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(&SPI3->DATAR);
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA2_Channel2, &DMA_InitStructure );
    SPI_I2S_DMACmd(SPI3, SPI_I2S_DMAReq_Tx, ENABLE);

    SPI_I2S_SendData(SPI3, 0x0000);//��������
}

void WS2812_Reset()
{
/*=====================================��������λ�źš�====================================*/
    Delay_Us(300);
}

void WS2812_SendData(unsigned long *_data)
{
/*========================================���������ݡ�=======================================
 * ������
 * _data��������ɫ��Ϣ������
 */

    uint16_t i, j = 0, k, buffersize;
    buffersize = WS2812_NUM * 24;
    uint16_t WS2812_buffer[buffersize];

    WS2812_Reset();
    for(k = 0;k < WS2812_NUM;k++)
    {
        for(i=8; i<16; i++)
        {
            WS2812_buffer[j] = ((_data[k]<<i) & 0x800000) ? TIMING_1:TIMING_0;//R
            j++;
        }
        for(i=0; i<8; i++)
        {
            WS2812_buffer[j] = ((_data[k]<<i) & 0x800000) ? TIMING_1:TIMING_0;//G
            j++;
        }
        for(i=16; i<24; i++)
        {
            WS2812_buffer[j] = ((_data[k]<<i) & 0x800000) ? TIMING_1:TIMING_0;//B
            j++;
        }
    }

    DMA_Cmd(DMA2_Channel2, DISABLE);
    DMA_SetCurrDataCounter(DMA2_Channel2, buffersize);
    DMA2_Channel2->MADDR = (u32)WS2812_buffer;
    DMA_Cmd(DMA2_Channel2, ENABLE);

    while(DMA_GetFlagStatus(DMA2_FLAG_TC2) != SET);

    DMA_Cmd(DMA2_Channel2, DISABLE);
    DMA_ClearFlag(DMA2_FLAG_TC2);

    WS2812_Reset();
    SPI_I2S_SendData(SPI3, 0x0000);//��������
}
