#ifndef __SHT30_H
#define __SHT30_H

//SHT30��ַ
#define SHT30_ADDR    (0x44<<1)

//SHT30�˿�
#define I2C_PORT        GPIOB
#define I2C_SCL_PIN     GPIO_Pin_10
#define I2C_SDA_PIN     GPIO_Pin_11

typedef struct
{
    float temperature;
    float humidity;
}SHT30_data_t;

void SHT30_Init();
unsigned char SHT30_Read();

extern SHT30_data_t SHT30;

#endif
