#include "SHT30.h"
#include "debug.h"
#include "CRC_SOFT.h"

SHT30_data_t SHT30 = {0};

void SHT30_Init()
{
//===============================����ʼ����================================

    GPIO_InitTypeDef GPIO_InitStructure = {0};
    I2C_InitTypeDef  I2C_InitTSturcture = {0};

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);     //ʹ��APB1 I2C2����ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);    //ʹ��APB2 GPIO����ʱ��

    GPIO_InitStructure.GPIO_Pin = I2C_SCL_PIN | I2C_SDA_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;         //����Ϊ���ÿ�©���ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(I2C_PORT, &GPIO_InitStructure);

    I2C_InitTSturcture.I2C_ClockSpeed = 100000;     //����I2C����
    I2C_InitTSturcture.I2C_Mode = I2C_Mode_I2C;
    I2C_InitTSturcture.I2C_DutyCycle = I2C_DutyCycle_2;
    I2C_InitTSturcture.I2C_OwnAddress1 = 0x01;     //ָ�����豸��ַ
    I2C_InitTSturcture.I2C_Ack = I2C_Ack_Enable;
    I2C_InitTSturcture.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    I2C_Init(I2C2, &I2C_InitTSturcture);
    I2C_Cmd(I2C2, ENABLE);
    I2C_AcknowledgeConfig(I2C2, ENABLE);
    Delay_Ms(1);
}

static void SHT30_I2C_Write(u8 dataH, u8 dataL)
{
    //������ʼ�ź�
    I2C_GenerateSTART(I2C2, ENABLE);
    //���͵�ַ&д
    while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT));
    I2C_Send7bitAddress(I2C2, SHT30_ADDR, I2C_Direction_Transmitter);
    while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));
    //��������
    I2C_SendData(I2C2, dataH);
    while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
    I2C_SendData(I2C2, dataL);
    while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_TRANSMITTED));
}
static void SHT30_I2C_Mem_Read(unsigned char len, unsigned char *buf)
{
    //������ʼ�ź�
    I2C_GenerateSTART(I2C2, ENABLE);
    //���͵�ַ&��
    while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_MODE_SELECT));
    I2C_Send7bitAddress(I2C2, SHT30_ADDR, I2C_Direction_Receiver);
    while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));

    while(len--)
    {
        if(len == 0)I2C_AcknowledgeConfig(I2C2, DISABLE);//NACK
        while(!I2C_CheckEvent(I2C2, I2C_EVENT_MASTER_BYTE_RECEIVED));
        *buf = I2C_ReceiveData(I2C2);
        buf++;
    }
    I2C_GenerateSTOP(I2C2, ENABLE);
    I2C_AcknowledgeConfig(I2C2, ENABLE);//ACK
}

unsigned char SHT30_Read()
{
//===============================����ȡ��ʪ�ȡ�================================
//����ֵ��������룬0��ʾ�ɹ�
//===========================================================================

    u8   temp_array[6] = {0};
    u16  temp_uint     = 0;

    //���������Բ���
    SHT30_I2C_Write(0x27, 0x37);//mps = 10,High repeat
    Delay_Ms(2);
    SHT30_I2C_Write(0xe0, 0x00);//read command
    SHT30_I2C_Mem_Read(6, temp_array);

    if(CRC_SOFT.CRC8(temp_array, 2) == temp_array[2])
    {
        temp_uint         = temp_array[0]<<8 | temp_array[1];
        SHT30.temperature = (float)(temp_uint * 0.00267032 - 45);
    }
    else return 1;

    if(CRC_SOFT.CRC8(temp_array + 3, 2) == temp_array[5])
    {
        temp_uint      = temp_array[3]<<8 | temp_array[4];
        SHT30.humidity = (float)(temp_uint * 0.00152590);
    }
    else return 2;

    return 0;
}
