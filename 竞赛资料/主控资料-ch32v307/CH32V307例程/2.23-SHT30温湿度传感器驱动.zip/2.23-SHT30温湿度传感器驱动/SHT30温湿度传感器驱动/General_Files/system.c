#include "system.h"
#include "debug.h"
#include  "../General_Files/drivers/SHT30.h"
#include "../General_Files/drivers/ST7789.h"

void System_Init()
{
    SHT30_Init();
    ST7789_Init();
    ST7789_ShowCHN(0, 32, "ʪ�ȣ�", color_WHITE, color_BLUE, SIZE_CHN_32x32);
    ST7789_ShowString(3*32+7*16, 32, "%RH", color_WHITE, color_BLUE, SIZE_ASCII_16x32);
    ST7789_ShowCHN(0, 64, "�¶ȣ�", color_WHITE, color_BLUE, SIZE_CHN_32x32);
    ST7789_ShowCHN(3*32+7*16, 64, "��", color_WHITE, color_BLUE, SIZE_CHN_32x32);
}

void System_Loop()
{
    if(SHT30_Read() == 0)
    {
        ST7789_ShowNumf(96, 32, SHT30.humidity, 4, color_WHITE, color_BLACK, SIZE_ASCII_16x32);
        ST7789_ShowNumf(96, 64, SHT30.temperature, 4, color_WHITE, color_BLACK, SIZE_ASCII_16x32);
        Delay_Ms(1000);
    }
}
