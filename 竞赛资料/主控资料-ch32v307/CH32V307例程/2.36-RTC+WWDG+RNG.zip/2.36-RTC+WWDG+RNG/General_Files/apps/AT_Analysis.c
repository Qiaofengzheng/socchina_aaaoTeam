#include "AT_Analysis.h"
#include "string.h"
#include "stdlib.h"
#include "debug.h"

void AT_Analysis(char *s)
{
//================================��ATָ�������==============================
//����:
//s:Ҫ�������ַ���
    unsigned char var = 0;
    for(char *str = strtok(s, "+="); str != 0; str = strtok(0, "+="))
    {
        if(var == 0)strcpy(AT.param_AT, str);
        if(var == 1)strcpy(AT.param1, str);
        if(var == 2)strcpy(AT.param2_s, str);
        var++;
    }

    var = 0;
    for(char *str = strtok(AT.param2_s, "/"); str != 0; str = strtok(0, "/"))
    {
        if(var == 0)strcpy(AT.param2_year, str);
        if(var == 1)strcpy(AT.param2_mon, str);
        if(var == 2)strcpy(AT.param2_day, str);
        if(var == 3)strcpy(AT.param2_hour, str);
        if(var == 4)strcpy(AT.param2_min, str);
        if(var == 5)strcpy(AT.param2_sec, str);
        var++;
    }
}

void AT_Clear()
{
//================================�����AT��������=============================
    memset(&AT, 0, sizeof(AT));
}
