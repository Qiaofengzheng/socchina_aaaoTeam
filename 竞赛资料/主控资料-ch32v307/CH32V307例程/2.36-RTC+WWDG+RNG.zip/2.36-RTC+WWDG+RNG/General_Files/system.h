#ifndef __SYSTEM_H
#define __SYSTEM_H

#ifdef __cplusplus
 extern "C" {
#endif

 typedef struct
 {
     volatile unsigned char rx_ok;
     volatile unsigned int rx_buff_len;
     unsigned char rx_buff[100];
 }UART1s_t;
 extern UART1s_t UART1s;

//============================��ϵͳ��ʼ����================================
void System_Init();

//==============================����ѭ����=================================
void System_Loop();

//=============================����������=================================
void System_Error_Handler();

#ifdef __cplusplus
 }
#endif

#endif /* __SYSTEM_H */


