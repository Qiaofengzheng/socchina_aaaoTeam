#include "system.h"
#include "CH58x_common.h"

#include "../General_Files/apps/AT_Analysis.h"
#include "string.h"

typedef struct
{
    volatile unsigned char rx_ok;
    volatile unsigned int rx_len;
    unsigned char rx_buff[100];
}UART1s_t;
UART1s_t UART1s = {.rx_ok = FALSE, .rx_len = 0, .rx_buff = 0};

AT_t AT = {0, 0, 0};

void System_Init()
{
    GPIOA_ModeCfg(GPIO_Pin_7, GPIO_ModeOut_PP_20mA);
    GPIOA_SetBits(GPIO_Pin_7);

    GPIOB_ModeCfg(GPIO_Pin_18 | GPIO_Pin_19, GPIO_ModeOut_PP_20mA);
    GPIOB_SetBits(GPIO_Pin_18 | GPIO_Pin_19);
}

void System_Loop()
{
    if(UART1s.rx_ok)
    {
        PRINT("%s", UART1s.rx_buff);

        AT_Analysis(UART1s.rx_buff);

        if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "NAME") != NULL)
            PRINT("LittleLeaf\r\n");
        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "IP") != NULL)
            PRINT("192.168.0.1\r\n");
        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "Baudrate") != NULL)
            PRINT("115200bps\r\n");

        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "OPEN") != NULL && AT.param2_d == 1)
            GPIOA_ResetBits(GPIO_Pin_7);
        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "OPEN") != NULL && AT.param2_d == 2)
            GPIOB_ResetBits(GPIO_Pin_19);
        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "OPEN") != NULL && AT.param2_d == 3)
            GPIOB_ResetBits(GPIO_Pin_18);

        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "CLOSE") != NULL && AT.param2_d == 1)
            GPIOA_SetBits(GPIO_Pin_7);
        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "CLOSE") != NULL && AT.param2_d == 2)
            GPIOB_SetBits(GPIO_Pin_19);
        else if(strstr(AT.param_AT, "AT") != NULL && strstr(AT.param1, "CLOSE") != NULL && AT.param2_d == 3)
            GPIOB_SetBits(GPIO_Pin_18);

        else if(strstr(AT.param_AT, "AT") != NULL)
            PRINT("OK!\r\n");

        PRINT("%s\r\n", AT.param_AT);
        PRINT("%s\r\n", AT.param1);
        PRINT("%s\r\n", AT.param2_s);//�յ�����������Դ�\r\n
        PRINT("%d\r\n", AT.param2_d);

        AT_Clear();
        memset(&UART1s, 0, sizeof(UART1s));
    }
}

/*********************************************************************
 * @fn      UART1_IRQHandler
 *
 * @brief   UART1�жϺ���
 *
 * @return  none
 */
__INTERRUPT
__HIGH_CODE
void UART1_IRQHandler(void)
{
    volatile uint8_t i;

    switch(UART1_GetITFlag())
    {
        case UART_II_LINE_STAT: // ��·״̬����
        {
            i = UART1_GetLinSTA();
            break;
        }

        case UART_II_RECV_TOUT: // ���ճ�ʱ����ʱһ֡���ݽ������
        case UART_II_RECV_RDY: // ���ݴﵽ���ô�����
            UART1s.rx_len += UART1_RecvString(UART1s.rx_buff + UART1s.rx_len);
            for (i = 0; i < UART1s.rx_len; ++i)
            {
                if(UART1s.rx_buff[i] == '\r')
                    if(UART1s.rx_buff[i+1] == '\n')
                    {
                        UART1s.rx_ok = TRUE;
                        break;
                    }
            }
            break;

        case UART_II_THR_EMPTY: // ���ͻ������գ��ɼ�������
            break;

        case UART_II_MODEM_CHG: // ֻ֧�ִ���0
            break;

        default:
            break;
    }
}
