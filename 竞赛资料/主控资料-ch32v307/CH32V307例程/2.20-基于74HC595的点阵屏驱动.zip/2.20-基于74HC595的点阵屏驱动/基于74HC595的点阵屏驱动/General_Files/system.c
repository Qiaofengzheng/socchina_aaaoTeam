#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/_8x8matrix.h"

const unsigned char pic[] =
{
    0x00,0x00,0x00,0x81,0xFF,0x81,0x00,0x00,//0,I

    0x0C,0x1E,0x3E,0x7C,0x7C,0x3E,0x1E,0x0C, //1,爱心（形状）

    0x42,0x7F,0x40,0x00,0x3E,0x49,0x49,0x30,//2,16
};

void BTIM6_Init();

void System_Init()
{
    BTIM6_Init();
    Matrix_Init();
}

void System_Loop()
{

}

void TIM6_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM6_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM6, TIM_IT_Update) == SET) //检查TIM6中断是否发生。
    {
        static volatile u16 i = 0, j = 0;
        Matrix_Display(pic, j);
        if(++i == 10000)
        {
            j++;
            if(j == 3)j = 0;
            i = 0;
        }
    }
    TIM_ClearITPendingBit(TIM6,TIM_IT_Update);    //清除TIM6的中断挂起位。
}

void BTIM6_Init()
{
    TIM_TimeBaseInitTypeDef TIM6_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);

    TIM6_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;    //定时器向上计数模式
    TIM6_InitStructure.TIM_Period = (1000000 / 10000) - 1;           //自动重载寄存器，1MHz/10000Hz(100us)
    TIM6_InitStructure.TIM_Prescaler = (SystemCoreClock / 1000000 - 1);//定时器预分频器设置 = 1MHz
    TIM_TimeBaseInit(TIM6, &TIM6_InitStructure);
    TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);                  //启用定时器6更新中断
    TIM_Cmd(TIM6, ENABLE);                                      //TIM6使能

    //初始化TIM NVIC，设置中断优先级分组
    NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;             //TIM6中断通道
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;   //设置抢占优先级0
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;           //设置响应优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;              //使能通道1中断
    NVIC_Init(&NVIC_InitStructure);                              //初始化NVIC
}
