#ifndef __8x8MATRIX_H
#define __8x8MATRIX_H

//============================�����Ŷ��塿=================================
#define _74HC595_PORT           GPIOC
#define _74HC595_SCLK_PIN       GPIO_Pin_10  //CLK
#define _74HC595_RCLK_PIN       GPIO_Pin_11  //LE
#define _74HC595_DIO_PIN        GPIO_Pin_12  //DI

#define _74HC595_SCLK_SET(n) GPIO_WriteBit(_74HC595_PORT, _74HC595_SCLK_PIN, n);
#define _74HC595_RCLK_SET(n) GPIO_WriteBit(_74HC595_PORT, _74HC595_RCLK_PIN, n);
#define _74HC595_DIO_SET(n)  GPIO_WriteBit(_74HC595_PORT, _74HC595_DIO_PIN, n);

void Matrix_Init();
void Matrix_Display(const unsigned char *_data, unsigned char index);

#endif
