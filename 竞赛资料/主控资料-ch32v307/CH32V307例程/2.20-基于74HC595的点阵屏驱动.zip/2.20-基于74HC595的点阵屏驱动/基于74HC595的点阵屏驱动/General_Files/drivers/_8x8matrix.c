#include "_8x8matrix.h"
#include "debug.h"

void Matrix_Init()
{
//==============================����ʼ����================================
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Pin =  _74HC595_SCLK_PIN | _74HC595_RCLK_PIN | _74HC595_DIO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(_74HC595_PORT, &GPIO_InitStructure);
}

static void Matrix_WriteByte(unsigned char data1,unsigned char data2)
{
//DATA1Ϊ��ɨ�����ݣ�DATA2Ϊ��ģ��Ϣ
	unsigned char i;

	_74HC595_RCLK_SET(0);

	for(i = 0;i < 8;i++)
	{
		if(data1 & 0x01){_74HC595_DIO_SET(1);}//��λ��ǰ
		else _74HC595_DIO_SET(0);
		_74HC595_SCLK_SET(0);
		Delay_Us(1);
		_74HC595_SCLK_SET(1);
		data1 >>= 1;			
	}	
	for(i = 0;i < 8;i++)
	{
        if(data2 & 0x01){_74HC595_DIO_SET(1);}//��λ��ǰ
        else _74HC595_DIO_SET(0);
        _74HC595_SCLK_SET(0);
        Delay_Us(1);
        _74HC595_SCLK_SET(1);
		data2 >>= 1;			
	}	
	_74HC595_RCLK_SET(1);
}

void Matrix_Display(const unsigned char *_data,unsigned char index)
{
//==============================����ʾͼ����================================
//������
//_data:�ֿ�
//_index:Ҫ��ʾ��ͼ��������
//ȡģ��ʽ:����ʽ/��λ��ǰ
//========================================================================
	unsigned char i, row = 0x80;//1000 0000

	for(i = 0 ; i < 8 ; i++)//��ɨ��һ��
	{
	    row = ~row; //0111 1111
	    Matrix_WriteByte(row,_data[(index * 8) + i]);//0x0C,0x1E,0x3E,0x7C,0x7C,0x3E,0x1E,0x0C
		row = ~row;//1000 0000
		row >>= 1;
	}		
}
