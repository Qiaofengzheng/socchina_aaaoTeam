#ifndef	__TM1638_H
#define	__TM1638_H

#define TM1638_PORT         GPIOB
#define TM1638_SCLK_PIN     GPIO_Pin_3  //CLK
#define TM1638_MOSI_PIN     GPIO_Pin_5  //DIO

#define TM1638_CS_PORT      GPIOA
#define TM1638_CS_PIN       GPIO_Pin_15 //STB

#define TM1638_SCLK_SET(n)  GPIO_WriteBit(TM1638_PORT, TM1638_SCLK_PIN, n)
#define TM1638_MOSI_SET(n)  GPIO_WriteBit(TM1638_PORT, TM1638_MOSI_PIN, n)
#define TM1638_MOSI_GET()   GPIO_ReadInputDataBit(TM1638_PORT, TM1638_MOSI_PIN)
#define TM1638_CS_SET(n)    GPIO_WriteBit(TM1638_CS_PORT, TM1638_CS_PIN, n)

void TM1638_Init(void);
void TM1638_ShowNum(unsigned char addr, unsigned char val);
void TM1638_ShowLED(unsigned char val);
unsigned char TM1638_ReadKey(void);

#endif
