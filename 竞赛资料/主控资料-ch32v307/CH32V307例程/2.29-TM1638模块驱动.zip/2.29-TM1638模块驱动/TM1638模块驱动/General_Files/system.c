#include "system.h"
#include "debug.h"

#include "../General_Files/drivers/TM1638.h"

void System_Init()
{
    TM1638_Init();
}

void System_Loop()
{
    unsigned char i;
    i = TM1638_ReadKey();              //������ֵ
    while(i == TM1638_ReadKey());      //���ּ��
    TM1638_ShowLED(i);
    TM1638_ShowNum(0, i);
    Delay_Ms(10);
}
