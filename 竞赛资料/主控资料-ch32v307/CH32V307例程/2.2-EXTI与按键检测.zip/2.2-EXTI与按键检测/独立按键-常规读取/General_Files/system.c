#include "system.h"
#include "debug.h"

void System_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_WriteBit(GPIOE, GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6, Bit_SET);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

void System_Loop()
{
    if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3) == Bit_RESET)
    {
        Delay_Ms(5);
        if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3) == Bit_RESET)
            GPIO_WriteBit(GPIOE, GPIO_Pin_0, !GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_0));
        while(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_3) == Bit_RESET);
    }
    if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_4) == Bit_RESET)
    {
        Delay_Ms(5);
        if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_4) == Bit_RESET)
            GPIO_WriteBit(GPIOE, GPIO_Pin_6, !GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_6));
        while(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_4) == Bit_RESET);
    }
    if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_5) == Bit_RESET)
    {
        Delay_Ms(5);
        if(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_5) == Bit_RESET)
            GPIO_WriteBit(GPIOE, GPIO_Pin_5, !GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_5));
        while(GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_5) == Bit_RESET);
    }
}
