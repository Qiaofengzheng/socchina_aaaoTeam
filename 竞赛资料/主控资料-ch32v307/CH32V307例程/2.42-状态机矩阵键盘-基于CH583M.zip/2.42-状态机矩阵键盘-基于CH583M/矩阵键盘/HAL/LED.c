#include "LED.h"
#include "config.h"

static unsigned char blink_num, blink_duty, EN;
static unsigned int blink_period, i, j;
static HAL_LED_id_t led;

static void HAL_LED_Ctrl(HAL_LED_id_t leds, unsigned char mode);

void HAL_LED_Init()
{
/*=====================����ʼ����===========================*/
	HAL_LED_PIN_INIT();
	HAL_LED_PORT |= HAL_LED_PIN;
}

static void HAL_LED_Ctrl(HAL_LED_id_t leds, unsigned char mode)
{
	if(mode != HAL_LED_MODE_TOGGLE)
	{
		if(leds & HAL_MASK_LED1)
		{
			if(mode == HAL_LED_MODE_ON)
				HAL_LED_PORT &= ~HAL_MASK_LED1;
			else
				HAL_LED_PORT |= HAL_MASK_LED1;
		}
		if(leds & HAL_MASK_LED2)
		{
			if(mode == HAL_LED_MODE_ON)
				HAL_LED_PORT &= ~HAL_MASK_LED2;
			else
				HAL_LED_PORT |= HAL_MASK_LED2;
		}
	}
	else
	{
		if(leds & HAL_MASK_LED1)
			HAL_LED_PORT ^= HAL_MASK_LED1;
		if(leds & HAL_MASK_LED2)
			HAL_LED_PORT ^= HAL_MASK_LED2;
	}
}

void HAL_LED_Set(HAL_LED_id_t leds, HAL_LED_mode_t mode)
{
/*=====================��LED���á�===========================
 * leds: LED����
 * mode: LEDģʽ
 */
	leds &= HAL_LED_PIN;
    switch(mode)
    {
        case HAL_LED_MODE_BLINK:
        {
        	HAL_LED_Blink(leds, HAL_LED_DEFAULT_BLINK_CNT, HAL_LED_DEFAULT_BLINK_DUTY, HAL_LED_DEFAULT_BLINK_PERIOD);//Ĭ��1s��˸һ�Σ���˸10��
            break;
        }
        case HAL_LED_MODE_ON:
        case HAL_LED_MODE_OFF:
        case HAL_LED_MODE_TOGGLE:
        {
			HAL_LED_Ctrl(leds, mode);
            break;
        }
        default:
            break;
    }
}

void HAL_LED_Blink(HAL_LED_id_t leds, unsigned char num, unsigned char duty, unsigned int period)
{
/*=====================��LED��˸��===========================
 * leds: LED����
 * num: ��˸����
 * duty: ռ�ձ�(%)
 * period: ��˸����(ms)
 */
	led = leds;
	blink_num = num;
    blink_duty = duty;
    blink_period = period << 1;
    i = 0;
    j = 0;
    HAL_LED_Ctrl(leds, HAL_LED_MODE_OFF);
    EN = RESET;
}

void HAL_LED_Tick()
{
/*=====================��LED������===========================
 * �ú�������ÿ1msִ��һ�Σ����δʹ��LED��˸�����ɺ���
 */
	if(j < 500)j++;
	else EN = SET;	//��ʱ500ms��ʼ��˸

	if(blink_num > 0 && EN == SET)
	{
		if(i > blink_period * blink_duty / 100)
			HAL_LED_Ctrl(led, HAL_LED_MODE_OFF);
		else
			HAL_LED_Ctrl(led, HAL_LED_MODE_ON);
		if(i++ > blink_period)
		{
			i = 0;
			blink_num--;
		}
	}
}

