#ifndef __LED_H
#define __LED_H

#define HAL_LED_TICK_TIME		1	//LED��������

#define HAL_LED_PORT			R32_PB_OUT
#define HAL_LED_PIN				(1 << 18)|(1 << 19)		//PB18|PB19
#define HAL_LED_PIN_INIT()		GPIOB_ModeCfg(HAL_LED_PIN, GPIO_ModeOut_PP_20mA);

//Ĭ��LED��˸����
#define HAL_LED_DEFAULT_BLINK_CNT		10
#define HAL_LED_DEFAULT_BLINK_DUTY		30
#define HAL_LED_DEFAULT_BLINK_PERIOD	500

typedef enum
{
	HAL_LED_MODE_OFF,
	HAL_LED_MODE_ON,
	HAL_LED_MODE_BLINK,
	HAL_LED_MODE_TOGGLE,
}HAL_LED_mode_t;

typedef enum
{
	HAL_MASK_LED1 = (1 << 18),	//PB18
	HAL_MASK_LED2 = (1 << 19),	//PB19
}HAL_LED_id_t;

void HAL_LED_Init();
void HAL_LED_Set(HAL_LED_id_t leds, HAL_LED_mode_t mode);
void HAL_LED_Blink(HAL_LED_id_t leds, unsigned char num, unsigned char duty, unsigned int period);
void HAL_LED_Tick();

#endif
