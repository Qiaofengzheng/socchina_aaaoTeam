#include "system.h"
#include "CONFIG.h"
#include "KEY.h"
#include "LED.h"

void System_Init()
{

}

void System_Loop()
{
	if(HAL_KEY_which.event == HAL_KEY_Event_Click)
	{
		PRINT("id: %d, event: Click\r\n", HAL_KEY_which.id);
		HAL_LED_Set(HAL_MASK_LED1 | HAL_MASK_LED2, HAL_LED_MODE_ON);
		tmos_memset(&HAL_KEY_which, 0, sizeof(HAL_KEY_which));
	}
	else if(HAL_KEY_which.event == HAL_KEY_Event_DoubleClick)
	{
		PRINT("id: %d, event: DoubleClick\r\n", HAL_KEY_which.id);
		HAL_LED_Set(HAL_MASK_LED1 | HAL_MASK_LED2, HAL_LED_MODE_OFF);
		tmos_memset(&HAL_KEY_which, 0, sizeof(HAL_KEY_which));
	}
	else if(HAL_KEY_which.event == HAL_KEY_Event_TripleClick)
	{
		PRINT("id: %d, event: TripleClick\r\n", HAL_KEY_which.id);
		HAL_LED_Set(HAL_MASK_LED1 | HAL_MASK_LED2, HAL_LED_MODE_TOGGLE);
		tmos_memset(&HAL_KEY_which, 0, sizeof(HAL_KEY_which));
	}
	else if(HAL_KEY_which.event == HAL_KEY_Event_LongPress)
	{
		PRINT("id: %d, event: LongPress, %dms\r\n", HAL_KEY_which.id, HAL_KEY_which.press_time * HAL_KEY_SCAN_TIME);
		HAL_LED_Set(HAL_MASK_LED1 | HAL_MASK_LED2, HAL_LED_MODE_BLINK);
		tmos_memset(&HAL_KEY_which, 0, sizeof(HAL_KEY_which));
	}
}
