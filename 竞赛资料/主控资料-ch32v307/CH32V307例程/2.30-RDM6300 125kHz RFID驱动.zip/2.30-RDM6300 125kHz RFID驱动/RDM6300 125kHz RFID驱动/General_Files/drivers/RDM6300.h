#ifndef __RDM6300_RTU_H
#define __RDM6300_RTU_H

#define RDM6300_UART        USART1

#define RDM6300_PORT        GPIOA
#define RDM6300_TX_PIN      GPIO_Pin_9
#define RDM6300_RX_PIN      GPIO_Pin_10

#define RX_BUFF_LENGTH 40

typedef struct
{
    unsigned char flag; //��ȡ��ɱ�־λ����ɺ���1
    unsigned char id[14];//14�ֽڿ���ID
}RDM6300_t;

void RDM6300_Init();

extern RDM6300_t RDM6300;

#endif
