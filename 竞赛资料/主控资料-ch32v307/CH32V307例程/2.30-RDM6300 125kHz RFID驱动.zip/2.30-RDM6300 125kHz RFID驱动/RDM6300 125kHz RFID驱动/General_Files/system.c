#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/RDM6300.h"

void System_Init()
{
    RDM6300_Init();
    printf("SystemClk:%d\r\n",SystemCoreClock);
    printf("This is printf example\r\n");
}

void System_Loop()
{
    unsigned char var;
    if(RDM6300.flag)
    {
        printf("RFID:");
        for(var = 0; var < 14; ++var)
            printf("%02x ", RDM6300.id[var]);
        printf("\r\n");
        RDM6300.flag = RESET;
    }
    Delay_Ms(500);
}
