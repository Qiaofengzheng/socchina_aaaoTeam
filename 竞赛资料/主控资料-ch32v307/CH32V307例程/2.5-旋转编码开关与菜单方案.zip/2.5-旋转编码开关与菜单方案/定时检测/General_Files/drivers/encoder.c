#include "debug.h"
#include "encoder.h"

void TIM6_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM6_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM6, TIM_IT_Update) == SET) //���TIM6�ж��Ƿ�����
	{
		static uint8_t i = 0;
		if(!ENCODER_A_READ())
		{
			i++;
		}
		else
		{
			if(ENCODER_B_READ() && (i > 10))
			{
			  encoder.Minus();
			  encoder.IT_flag = SET;
			  i = 0;
			}
			else if(!ENCODER_B_READ() && (i > 10))
			{
			  encoder.Add();
			  encoder.IT_flag = SET;
			  i = 0;
			}
		}
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	}
}

void EXTI3_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI3_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line3) == SET)
    {
      encoder.Enter();
      encoder.IT_flag = SET;
    }
    EXTI_ClearITPendingBit(EXTI_Line3);     /* Clear Flag */
}
