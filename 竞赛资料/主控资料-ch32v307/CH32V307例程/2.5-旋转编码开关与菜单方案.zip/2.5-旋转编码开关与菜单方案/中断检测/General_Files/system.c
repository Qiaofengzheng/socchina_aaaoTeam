#include "system.h"
#include "debug.h"

#include  "../General_Files/drivers/SSD1306.h"
#include  "../General_Files/drivers/encoder.h"
#include  "../General_Files/apps/Menu.h"

void System_Init()
{
    SSD1306_Init();
    encoder.Init();
}

void System_Loop()
{
    if(encoder.IT_flag == SET)
    {
        menu[menu_run.func_index].run_func();
        encoder.IT_flag = RESET;
    }
}
