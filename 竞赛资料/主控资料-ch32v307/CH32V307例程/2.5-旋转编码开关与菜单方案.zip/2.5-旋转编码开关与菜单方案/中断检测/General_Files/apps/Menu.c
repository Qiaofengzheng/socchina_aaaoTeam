#include "debug.h"
#include "Menu.h"
#include "../General_Files/drivers/encoder.h"
#include "../General_Files/drivers/SSD1306.h"

void Set_Menu1();
void Set_Menu2();
void Set_Menu3();
void Set_Menu4();
void Set_Menu5();
void Set_Menu6();
void Set_Menu7();
void Set_Menu8();
void Hello();
void Encoder_Init();
void Encoder_Up();
void Encoder_Down();
void Encoder_Enter();

encoder_t encoder = { SET, Encoder_Up, Encoder_Down, Encoder_Enter, Encoder_Init};
menu_runStructure menu_run = {0};

menuStructure_t menu[MENU_NUM] =
{
	{0,3,1,4,Set_Menu1},//
	{1,0,2,4,Set_Menu2},//
	{2,1,3,4,Set_Menu3},//
	{3,2,0,4,Set_Menu4},//

    {4,4,4,0,Hello},//
};

void Encoder_Up()
{
    menu_run.func_index = menu[menu_run.func_index].up_index;
}
void Encoder_Down()
{
    menu_run.func_index = menu[menu_run.func_index].down_index;
}
void Encoder_Enter()
{
    menu_run.func_index = menu[menu_run.func_index].enter_index;
}
void Encoder_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* GPIOC ----> EXTI_Line4 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource4);
    EXTI_InitStructure.EXTI_Line = EXTI_Line4;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /* GPIOC ----> EXTI_Line3 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource3);
    EXTI_InitStructure.EXTI_Line = EXTI_Line3;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    menu[menu_run.func_index].run_func();
}
void Hello()
{
    SSD1306_Fill(0x00, SSD1306_PO);
    SSD1306_ShowCN(0, 0, "���ã�СҶ�ӡ�", SSD1306_PO);
}
void Set_Menu1()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu2()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu3()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu4()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu5()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu6()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu7()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_NE);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_PO);
}
void Set_Menu8()
{
    SSD1306_ShowStr(0, 0, "Menu1", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "Menu2", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Menu3", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 6, "Menu4", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 0, "Menu5", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 2, "Menu6", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 4, "Menu7", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(63, 6, "Menu8", SSD1306_SIZE_16, SSD1306_NE);
}
