#include "system.h"
#include "debug.h"

#include "../General_Files/drivers/HT1621.h"

void System_Init()
{
    HT1621_Init();
}

void System_Loop()
{
//1.
//    HT1621_Beep(ENABLE);
//    Delay_Ms(50);
//    HT1621_Beep(DISABLE);
//    Delay_Ms(950);

//2.
    static unsigned char i = 0, j = 0;
    HT1621_ShowVoltage(i);
    HT1621_ShowQuantity(j);
    if(i++ >199)i = 0;
    if(j++ > 100)j = 0;
    Delay_Ms(100);
}
