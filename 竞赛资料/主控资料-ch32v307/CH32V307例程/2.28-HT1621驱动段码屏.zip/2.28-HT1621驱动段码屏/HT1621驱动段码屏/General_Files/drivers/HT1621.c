#include  "HT1621.h"
#include  "debug.h"

static unsigned char global_delay = 1;

static void HT1621_SendM2L(unsigned char data, unsigned char num)
{
	unsigned char i;
	for(i = 0;i < num; i++)
	{
		HT1621_SCLK_SET(0);
		if(data & 0x80)HT1621_MOSI_SET(1);
		else HT1621_MOSI_SET(0);
		Delay_Us(global_delay);
		HT1621_SCLK_SET(1);
		Delay_Us(global_delay);
		data <<= 1;
	}
}
static void HT1621_SendL2M(unsigned char data, unsigned char num)
{
	unsigned char i;
	for(i = 0;i < num; i++)
	{
		HT1621_SCLK_SET(0);
		if(data & 0x01)HT1621_MOSI_SET(1);
		else HT1621_MOSI_SET(0);
		Delay_Us(global_delay);
		HT1621_SCLK_SET(1);
		Delay_Us(global_delay);
		data >>= 1;
	}
}
static void HT1621_SendCmd(unsigned char cmd)
{
	HT1621_CS_SET(0);
	Delay_Us(global_delay);
	HT1621_SendM2L(WCMD, 3);
	HT1621_SendM2L(cmd, 9);
	HT1621_CS_SET(1);
	Delay_Us(global_delay);
}
static void HT1621_SendData(unsigned char addr, unsigned char data)
{
	HT1621_CS_SET(0);
	Delay_Us(global_delay);
	HT1621_SendM2L(WDAT, 3);
	//�������ӵ�ַ����Ϊ��λ�ȷ�����ַֻ��6λ������λ
	HT1621_SendM2L(addr << 2, 6);
	HT1621_SendL2M(data, 4);
	HT1621_CS_SET(1);
	Delay_Us(global_delay);
}

void HT1621_Init()
{
//============================����ʼ��HT1621��================================
    GPIO_InitTypeDef GPIO_InitStructure={0};

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOE, ENABLE );

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Pin = HT1621_SCLK_PIN | HT1621_MOSI_PIN;
    GPIO_Init( HT1621_PORT, &GPIO_InitStructure );

    GPIO_InitStructure.GPIO_Pin = HT1621_CS_PIN;
    GPIO_Init( HT1621_CS_PORT, &GPIO_InitStructure );

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = HT1621_nIRQ_PIN;
    GPIO_Init( HT1621_nIRQ_PORT, &GPIO_InitStructure );

	HT1621_SendCmd(0x29);       //1/3Bias 4COMS duty = 1/COMS
	HT1621_SendCmd(0x01);       //SYS EN
	HT1621_SendCmd(0x03);       //LCD ON
	HT1621_Clear();             //
	HT1621_SendData(1, 0x03);   //��ʾ��ѹ����������
}

void HT1612_OFF()
{
//==============================���ر�HT1621��=============================
    HT1621_SendCmd(0x00);
}

void HT1621_Beep(unsigned char newState)
{
//============================��������ʹ�ܡ�==============================
//������
//newState:x����
//======================================================================
    if(newState == ENABLE)
    {
        HT1621_SendCmd(0x40);//2kHz = 0x60,(4kHz = 0x40)
        HT1621_SendCmd(0x09);//Beep EN
    }
    else HT1621_SendCmd(0x08);
}

void HT1621_Clear()
{
//==============================��������===================================
    unsigned char i;
    for(i = 0;i < 15;i++)HT1621_SendData(i, 0x00);
}

void HT1621_ShowVoltage(unsigned char val)
{
//=============================����ʾ��ѹ��===============================
//������
//val:����ʵ�ʵ�ѹֵ*10����Χ0 - 199����Ӧ0.0 - 19.9v
//======================================================================
    unsigned char s, g;

    s = val / 10 % 10;
    g = val / 1 % 10;

    switch(s)
    {
        case 0:HT1621_SendData(8,0x0f);HT1621_SendData(0,0x0a|(val > 99?0x01:0x00));break;
        case 1:HT1621_SendData(8,0x06);HT1621_SendData(0,0x00|(val > 99?0x01:0x00));break;
        case 2:HT1621_SendData(8,0x0d);HT1621_SendData(0,0x06|(val > 99?0x01:0x00));break;
        case 3:HT1621_SendData(8,0x0f);HT1621_SendData(0,0x04|(val > 99?0x01:0x00));break;
        case 4:HT1621_SendData(8,0x06);HT1621_SendData(0,0x0c|(val > 99?0x01:0x00));break;
        case 5:HT1621_SendData(8,0x0b);HT1621_SendData(0,0x0c|(val > 99?0x01:0x00));break;
        case 6:HT1621_SendData(8,0x0b);HT1621_SendData(0,0x0e|(val > 99?0x01:0x00));break;
        case 7:HT1621_SendData(8,0x0e);HT1621_SendData(0,0x00|(val > 99?0x01:0x00));break;
        case 8:HT1621_SendData(8,0x0f);HT1621_SendData(0,0x0e|(val > 99?0x01:0x00));break;
        case 9:HT1621_SendData(8,0x0f);HT1621_SendData(0,0x0c|(val > 99?0x01:0x00));break;
    }
    switch(g)
    {
        case 0:HT1621_SendData(10,0x0f);HT1621_SendData(9,0x0a|0x01);break;
        case 1:HT1621_SendData(10,0x06);HT1621_SendData(9,0x00|0x01);break;
        case 2:HT1621_SendData(10,0x0d);HT1621_SendData(9,0x06|0x01);break;
        case 3:HT1621_SendData(10,0x0f);HT1621_SendData(9,0x04|0x01);break;
        case 4:HT1621_SendData(10,0x06);HT1621_SendData(9,0x0c|0x01);break;
        case 5:HT1621_SendData(10,0x0b);HT1621_SendData(9,0x0c|0x01);break;
        case 6:HT1621_SendData(10,0x0b);HT1621_SendData(9,0x0e|0x01);break;
        case 7:HT1621_SendData(10,0x0e);HT1621_SendData(9,0x00|0x01);break;
        case 8:HT1621_SendData(10,0x0f);HT1621_SendData(9,0x0e|0x01);break;
        case 9:HT1621_SendData(10,0x0f);HT1621_SendData(9,0x0c|0x01);break;
    }
}
void HT1621_ShowQuantity(unsigned char val)
{
//=============================����ʾ������===============================
//������
//val:����ֵ����Χ0 - 100
//======================================================================
    unsigned char s, g;

    s = val / 10 % 10;
    g = val / 1 % 10;
    if(val > 9)
    {
        switch(s)
        {
            case 0:HT1621_SendData(3,0x0f);HT1621_SendData(2,0x0a|(val > 99?0x01:0x00));break;//�����²���ʾ��λ
            case 1:HT1621_SendData(3,0x06);HT1621_SendData(2,0x00|(val > 99?0x01:0x00));break;
            case 2:HT1621_SendData(3,0x0d);HT1621_SendData(2,0x06|(val > 99?0x01:0x00));break;
            case 3:HT1621_SendData(3,0x0f);HT1621_SendData(2,0x04|(val > 99?0x01:0x00));break;
            case 4:HT1621_SendData(3,0x06);HT1621_SendData(2,0x0c|(val > 99?0x01:0x00));break;
            case 5:HT1621_SendData(3,0x0b);HT1621_SendData(2,0x0c|(val > 99?0x01:0x00));break;
            case 6:HT1621_SendData(3,0x0b);HT1621_SendData(2,0x0e|(val > 99?0x01:0x00));break;
            case 7:HT1621_SendData(3,0x0e);HT1621_SendData(2,0x00|(val > 99?0x01:0x00));break;
            case 8:HT1621_SendData(3,0x0f);HT1621_SendData(2,0x0e|(val > 99?0x01:0x00));break;
            case 9:HT1621_SendData(3,0x0f);HT1621_SendData(2,0x0c|(val > 99?0x01:0x00));break;
        }
    }
    else//ʮ���²���ʾʮλ�����ʮλ
    {
        HT1621_SendData(3,0x00);
        HT1621_SendData(2,0x00);
    }

    switch(g)
    {
        case 0:HT1621_SendData(7,0x0f);HT1621_SendData(4,0x0a);break;
        case 1:HT1621_SendData(7,0x06);HT1621_SendData(4,0x00);break;
        case 2:HT1621_SendData(7,0x0d);HT1621_SendData(4,0x06);break;
        case 3:HT1621_SendData(7,0x0f);HT1621_SendData(4,0x04);break;
        case 4:HT1621_SendData(7,0x06);HT1621_SendData(4,0x0c);break;
        case 5:HT1621_SendData(7,0x0b);HT1621_SendData(4,0x0c);break;
        case 6:HT1621_SendData(7,0x0b);HT1621_SendData(4,0x0e);break;
        case 7:HT1621_SendData(7,0x0e);HT1621_SendData(4,0x00);break;
        case 8:HT1621_SendData(7,0x0f);HT1621_SendData(4,0x0e);break;
        case 9:HT1621_SendData(7,0x0f);HT1621_SendData(4,0x0c);break;
    }

    if(val <= 5){HT1621_SendData(5,0x00|0x01|0x08);HT1621_SendData(6,0x00|0x08);}
    else if(val <= 20){HT1621_SendData(5,0x00|0x01|0x08);HT1621_SendData(6,0x01|0x08);}
    else if(val <= 40){HT1621_SendData(5,0x02|0x01|0x08);HT1621_SendData(6,0x01|0x08);}
    else if(val <= 60){HT1621_SendData(5,0x06|0x01|0x08);HT1621_SendData(6,0x01|0x08);}
    else if(val <= 80){HT1621_SendData(5,0x06|0x01|0x08);HT1621_SendData(6,0x03|0x08);}
    else {HT1621_SendData(5,0x06|0x01|0x08);HT1621_SendData(6,0x07|0x08);}
}
