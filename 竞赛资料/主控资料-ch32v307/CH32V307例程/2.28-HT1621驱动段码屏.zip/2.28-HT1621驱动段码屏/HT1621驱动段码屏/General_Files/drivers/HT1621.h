#ifndef	__HT1621_H
#define	__HT1621_H

#define HT1621_PORT         GPIOB
#define HT1621_SCLK_PIN     GPIO_Pin_3  //WR
#define HT1621_MOSI_PIN     GPIO_Pin_5  //DATA

#define HT1621_CS_PORT      GPIOA
#define HT1621_CS_PIN       GPIO_Pin_15

#define HT1621_nIRQ_PORT    GPIOE
#define HT1621_nIRQ_PIN     GPIO_Pin_2

#define HT1621_SCLK_SET(n)  GPIO_WriteBit(HT1621_PORT, HT1621_SCLK_PIN, n)
#define HT1621_MOSI_SET(n)  GPIO_WriteBit(HT1621_PORT, HT1621_MOSI_PIN, n)
#define HT1621_CS_SET(n)    GPIO_WriteBit(HT1621_CS_PORT, HT1621_CS_PIN, n)
#define HT1621_nIRQ_GET()     GPIO_ReadInputDataBit(HT1621_nIRQ_PORT, HT1621_nIRQ_PIN)

#define WCMD 0x80   //1000 0000
#define WDAT 0xA0   //1010 0000

void HT1621_Init();
void HT1621_OFF();
void HT1621_Beep(unsigned char newState);
void HT1621_Clear();
void HT1621_ShowVoltage(unsigned char val);
void HT1621_ShowQuantity(unsigned char val);
#endif

//		HT1621_SendData(2,0x01);//4BC

//		HT1621_SendData(8,0x08);//2A
//		HT1621_SendData(8,0x04);//2B	
//		HT1621_SendData(8,0x02);//2C
//		HT1621_SendData(8,0x01);//2D		
//		HT1621_SendData(0,0x02);//2E
//		HT1621_SendData(0,0x08);//2F
//		HT1621_SendData(0,0x04);//2G		

//		HT1621_SendData(10,0x08);//3A
//		HT1621_SendData(10,0x04);//3B
//		HT1621_SendData(10,0x02);//3C
//		HT1621_SendData(10,0x01);//3D
//		HT1621_SendData(9,0x02);//3E
//		HT1621_SendData(9,0x08);//3F
//		HT1621_SendData(9,0x04);//3G	

//		HT1621_SendData(3,0x08);//5A	
//		HT1621_SendData(3,0x04);//5B
//		HT1621_SendData(3,0x02);//5C
//		HT1621_SendData(3,0x01);//5D
//		HT1621_SendData(2,0x02);//5E
//		HT1621_SendData(2,0x08);//5F
//		HT1621_SendData(2,0x04);//5G
		
//		HT1621_SendData(7,0x08);//6A
//		HT1621_SendData(7,0x04);//6B
//		HT1621_SendData(7,0x02);//6C
//		HT1621_SendData(7,0x01);//6D
//		HT1621_SendData(4,0x02);//6E
//		HT1621_SendData(4,0x08);//6F
//		HT1621_SendData(4,0x04);//6G

//		HT1621_SendData(5,0x08);//L1
//		HT1621_SendData(6,0x04);//L2
//		HT1621_SendData(6,0x02);//L3
//		HT1621_SendData(5,0x04);//L4
//		HT1621_SendData(5,0x02);//L5
//		HT1621_SendData(6,0x01);//L6
