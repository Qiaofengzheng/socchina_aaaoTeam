#ifndef __KEY_H
#define __KEY_H

#define HAL_KEY_SCAN_TIME		50		//ɨ��һ�ε�ʱ��
#define HAL_KEY_LONG_PRESS_TIME	800	//�ж�Ϊ������ʱ����ֵ

#define HAL_KEY_PORT_READ() 	R32_PB_PIN
#define HAL_KEY_PIN				(0xFF)
#define HAL_KEY_PIN_INIT()		GPIOB_ModeCfg(HAL_KEY_PIN, GPIO_ModeIN_PU)

typedef enum
{
	HAL_MASK_KEY1 = 0x01,
	HAL_MASK_KEY2 = 0x02,
	HAL_MASK_KEY3 = 0x04,
	HAL_MASK_KEY4 = 0x08,
	HAL_MASK_KEY5 = 0x10,
	HAL_MASK_KEY6 = 0x20,
	HAL_MASK_KEY7 = 0x40,
	HAL_MASK_KEY8 = 0x80,
}HAL_KEY_id_t;

typedef enum
{
	HAL_KEY_Event_NULL,
	HAL_KEY_Event_Click,
	HAL_KEY_Event_DoubleClick,
	HAL_KEY_Event_TripleClick,
	HAL_KEY_Event_LongPress,
}HAL_KEY_event_t;

typedef struct
{
	HAL_KEY_id_t  id;				//�������
	HAL_KEY_event_t event;			//�����¼�
    unsigned char press_time;		//�����¼���ʱ��
}HAL_KEY_which_t;

void HAL_KEY_Init();
void HAL_KEY_Scan();

extern HAL_KEY_which_t HAL_KEY_which;

#endif

