#ifndef __ADC_DRV_H
#define __ADC_DRV_H

#define ADC_PORT GPIOA
#define ADC_LEVEL_PIN GPIO_Pin_1

#define LEVEL_CHANNEL ADC_Channel_1

void ADC_User_Init();
unsigned int ADC_Get_Average(unsigned char ch, unsigned char times);

#endif
