#include "debug.h"
#include "dac_drv.h"

void DAC_User_Init()
{
//=========================��DAC��ʼ����==============================
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    DAC_InitTypeDef  DAC_InitType = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Pin = DAC1_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DAC_PORT, &GPIO_InitStructure);

    DAC_InitType.DAC_Trigger = DAC_Trigger_None;
    DAC_InitType.DAC_WaveGeneration = DAC_WaveGeneration_None;
    DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;
    DAC_InitType.DAC_OutputBuffer = DAC_OutputBuffer_Disable;
    DAC_Init(DAC_Channel_1, &DAC_InitType);
    DAC_Cmd(DAC_Channel_1, ENABLE);

    DAC_SetChannel1Data(DAC_Align_12b_R, 0);
}

void DAC_Set_Voltage(unsigned char DAC_channel, unsigned int voltage)
{
//=========================�����������ѹ��==============================
//������
//DAC_channel:DAC1��DAC2,���Խ��л����
//voltage:Ҫ����ĵ�ѹֵ(mV)
//=====================================================================
    if(DAC_channel & 0x01)DAC_SetChannel1Data(DAC_Align_12b_R, (voltage * 4096)/VREF);
    if(DAC_channel & 0x02)DAC_SetChannel2Data(DAC_Align_12b_R, (voltage * 4096)/VREF);
}
