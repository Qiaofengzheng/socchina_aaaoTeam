#ifndef __DAC_DRV_H
#define __DAC_DRV_H

#define DAC_PORT GPIOA
#define DAC1_PIN GPIO_Pin_4
#define DAC2_PIN GPIO_Pin_5

#define DAC1 0x01
#define DAC2 0x02

#define VREF 3180//�ο���ѹֵ(mV)

void DAC_User_Init();
void DAC_Set_Voltage(unsigned char DAC_channel, unsigned int voltage);

#endif /* __DAC_H */
