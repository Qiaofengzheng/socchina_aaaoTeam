#include "system.h"
#include "debug.h"
#include "../General_Files/drivers/SSD1306.h"
#include "../General_Files/drivers/dac_drv.h"
#include "../General_Files/drivers/adc_drv.h"
#include "../General_Files/drivers/IL9341.h"
#include "../General_Files/apps/PID.h"

//用于记录波形数据的数组
uint8_t wave_level[288] = {0};

//PID参数结构体
PID_t PID_level =
{
    2.0,//kp
    0.2,//ki
    0.0,//kd

    0.0,//err_sum
    15,//I_MAX
    20,//result_MAX

    0,//err
    0,//err_last
    0,//result

    8,//target
    0,//feedback
};

void LED_Init();
void BTIM6_Init();
void Show_wave(uint8_t *array, uint8_t new_data);
void IWDG_Feed_Init(u16 prer, u16 rlr);

void System_Init()
{
    DAC_User_Init();//DAC先初始化，因为要防止误操作设备
    LED_Init();//LED初始化
    SSD1306_Init();//小屏幕初始化
    IL9341_Init();//大屏幕初始化
    BTIM6_Init();//定时器初始化

    uint8_t i;
    //显示纵坐标刻度值
    for(i = 0; i < 5; i++)IL9341_ShowNum(0, LCD_HEIGHT - 20 - 24 * i, i * 6, 2, color_WHITE, color_BLACK, IL9341_SIZE_ASCII_16x8);
    IL9341_ShowString(0, LCD_HEIGHT - 20 - 24 * 5, "(mA)", color_WHITE, color_BLACK, IL9341_SIZE_ASCII_16x8);

    //小屏幕UI初始化
    SSD1306_ShowStr(0, 0, "L_SV ->", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(64+16, 0, "mA", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 2, "L_PV ->", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(64+16, 2, "mA", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(0, 4, "Pump ->", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowStr(64+16, 4, "mA", SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowNum(64, 0, PID_level.target, 2, SSD1306_SIZE_16, SSD1306_PO);

    //ADC初始化
    ADC_User_Init();

    //配置并启动看门狗（看门狗初始化）
    IWDG_Feed_Init(IWDG_Prescaler_4, 4000);//LSI典型值为39kHz,4分频后为9.75kHz,计时4000次约为410ms
}

void System_Loop()
{
    PID_level.feedback = (ADC_Get_Average(LEVEL_CHANNEL, 5)*3300)/4096/150;//更新AD值
    PID_Process(&PID_level);//进行PID处理
    DAC_SetChannel1Data(DAC_Align_12b_R, (PID_level.result/33.0)*4096);//更新DA值
    Show_wave(wave_level,  PID_level.target);//刷新波形

    //将最新的值显示在小屏幕上
    SSD1306_ShowNum(64, 2, PID_level.feedback, 2, SSD1306_SIZE_16, SSD1306_PO);
    SSD1306_ShowNum(64, 4, PID_level.result, 2, SSD1306_SIZE_16, SSD1306_PO);

    Delay_Ms(300);//全局延时

    IWDG_ReloadCounter(); //喂狗
}

void TIM6_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM6_IRQHandler(void)
{
    static volatile uint16_t i = 0;
    if(TIM_GetITStatus(TIM6, TIM_IT_Update) == SET) //检查TIM6中断是否发生。
    {
      if(++i >= 500)
      {
          GPIO_WriteBit(GPIOE, GPIO_Pin_0, !GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_0));//每500ms闪灯
          i = 0;
      }
      TIM_ClearITPendingBit(TIM6,TIM_IT_Update);    //清除TIM6的中断挂起位。
    }
}

void Show_wave(uint8_t *array, uint8_t new_data)
{
    uint16_t i;
    IL9341_DrawRectangle(16, 132, 12 * 24, 4 * 24, color_BLACK, 1, ENABLE);//绘制黑色矩形区域
    for(i = 0; i < 4; i++)
        IL9341_DrawLine(16, LCD_HEIGHT - 12 - 24 * i, LCD_WIDTH - 16, LCD_HEIGHT - 12 - 24 * i, color_YELLOW, 1);//绘制3根水平线
    for(i = 1; i < 12; i++)
        IL9341_DrawLine(16 + 24 * i, LCD_HEIGHT - 12, 16 + 24 * i, LCD_HEIGHT - 12 - 4 * 24, color_YELLOW, 1);//绘制11根垂直线

    for(i = 0; i < 288 - 1; i++)//将数组的数据全部显示到绘图区域（显示波形），显示数组第i个元素与i+1个元素的直线
        IL9341_DrawLine(16 + i, LCD_HEIGHT - 12 - array[i] * 4, 16 + i + 1,LCD_HEIGHT - 12 - array[i + 1] * 4, color_RED, 1);

    for(i = 0; i < 288 - 1; i++)array[i] = array[i + 1];//对数组元素进行左移

    array[287] = new_data;//将最新的数据作为数组最后一个元素
}

void BTIM6_Init()
{
    TIM_TimeBaseInitTypeDef TIM6_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);

    TIM6_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;    //定时器向上计数模式
    TIM6_InitStructure.TIM_Period = (1000000 / 1000) - 1;           //自动重载寄存器，1MHz/1000Hz(1ms)
    TIM6_InitStructure.TIM_Prescaler = (SystemCoreClock / 1000000 - 1);//定时器预分频器设置 = 1MHz
    TIM_TimeBaseInit(TIM6, &TIM6_InitStructure);
    TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);                  //启用定时器6更新中断
    TIM_Cmd(TIM6, ENABLE);                                      //TIM6使能

    //初始化TIM NVIC，设置中断优先级分组
    NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;             //TIM6中断通道
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;   //设置抢占优先级0
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;           //设置响应优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;              //使能通道1中断
    NVIC_Init(&NVIC_InitStructure);                              //初始化NVIC
}

void LED_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
}

/*********************************************************************
 * @fn      IWDG_Init
 *
 * @brief   Initializes IWDG.
 *
 * @param   IWDG_Prescaler - specifies the IWDG Prescaler value.
 *            IWDG_Prescaler_4 - IWDG prescaler set to 4.
 *            IWDG_Prescaler_8 - IWDG prescaler set to 8.
 *            IWDG_Prescaler_16 - IWDG prescaler set to 16.
 *            IWDG_Prescaler_32 - IWDG prescaler set to 32.
 *            IWDG_Prescaler_64 - IWDG prescaler set to 64.
 *            IWDG_Prescaler_128 - IWDG prescaler set to 128.
 *            IWDG_Prescaler_256 - IWDG prescaler set to 256.
 *          Reload - specifies the IWDG Reload value.
 *            This parameter must be a number between 0 and 0x0FFF.
 *
 * @return  none
 */
void IWDG_Feed_Init(u16 prer, u16 rlr)
{
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);//使能寄存器访问
    IWDG_SetPrescaler(prer);//设置分频系数
    IWDG_SetReload(rlr);//设置重装载值
    IWDG_ReloadCounter();//重装载计数值
    IWDG_Enable();//使能看门狗
}
