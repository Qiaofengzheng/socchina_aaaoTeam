#ifndef __MAX7219_H
#define __MAX7219_H

//============================�����Ŷ��塿=================================
#define MAX7219_PORT          GPIOC
#define MAX7219_CLK_PIN       GPIO_Pin_10
#define MAX7219_CS_PIN        GPIO_Pin_11
#define MAX7219_DIN_PIN       GPIO_Pin_12

#define MAX7219_CLK_SET(n)  GPIO_WriteBit(MAX7219_PORT, MAX7219_CLK_PIN, n);
#define MAX7219_CS_SET(n)   GPIO_WriteBit(MAX7219_PORT, MAX7219_CS_PIN, n);
#define MAX7219_DIN_SET(n)  GPIO_WriteBit(MAX7219_PORT, MAX7219_DIN_PIN, n);

void MAX7219_Init(void);
void MAX7219_Write_Data(unsigned char addr, unsigned char _data);

#endif
