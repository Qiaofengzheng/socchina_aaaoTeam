#include "system.h"
#include "debug.h"
#include "../General_Files/apps/iap.h"

void System_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure = {0};

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);

	IAP_Init();
	printf("Boot Loader running...\r\n");
}

void System_Loop()
{
    GPIO_TogglePin(GPIOE, GPIO_Pin_0 | GPIO_Pin_5 | GPIO_Pin_6);
    Delay_Ms(500);
}

