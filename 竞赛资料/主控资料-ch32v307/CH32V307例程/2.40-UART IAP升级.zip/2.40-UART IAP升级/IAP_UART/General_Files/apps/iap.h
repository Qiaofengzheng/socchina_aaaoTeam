#ifndef __IAP_H
#define __IAP_H

void IAP_Init();
void IAP_Update();
void IAP_To_APP();

#endif
