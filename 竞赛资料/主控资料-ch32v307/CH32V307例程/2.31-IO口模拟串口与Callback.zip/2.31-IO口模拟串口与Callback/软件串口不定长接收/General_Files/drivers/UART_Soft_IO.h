#ifndef __UART_SOFT_IO_H
#define __UART_SOFT_IO_H

#define UART_SOFT_IO_PORT       GPIOC
#define UART_SOFT_IO_TX_PIN     GPIO_Pin_11
#define UART_SOFT_IO_RX_PIN     GPIO_Pin_10

#define UART_SOFT_IO_TX(n)      GPIO_WriteBit(UART_SOFT_IO_PORT, UART_SOFT_IO_TX_PIN, n)
#define UART_SOFT_IO_RX()       GPIO_ReadInputDataBit(UART_SOFT_IO_PORT, UART_SOFT_IO_RX_PIN)

typedef void (*TX_LED_StateCB_t)(unsigned char);

typedef struct
{
    void(*Init)(unsigned long);
    void(*TX)(unsigned char);
    void(*TXString)(unsigned char *, TX_LED_StateCB_t);
    void(*Clear)(void);
    volatile unsigned char RX_OK_flag;   //������ɱ�־λ
    volatile unsigned char RX_len;       //���ճ���
    volatile unsigned char RX_data[255]; //���ջ�������С
}UART_SOFT_IO_t;

extern UART_SOFT_IO_t UART_Soft_IO;

#endif /* __UART_SOFT_IO_H */
