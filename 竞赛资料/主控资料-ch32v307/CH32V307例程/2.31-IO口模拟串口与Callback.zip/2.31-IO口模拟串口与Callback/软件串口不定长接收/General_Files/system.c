#include "system.h"
#include "debug.h"

#include "../General_Files/drivers/UART_Soft_IO.h"

void LED_State(unsigned char sta);

void System_Init()
{
    //LED
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    GPIO_WriteBit(GPIOE, GPIO_Pin_0, Bit_SET);

    UART_Soft_IO.Init(9600);
}

void System_Loop()
{
//1.�ص���������
    UART_Soft_IO.TXString("Hello WCH!\r\n", LED_State);
    Delay_Ms(200);

//2.���ڲ��������ղ���
//    unsigned char var;
//    if(UART_Soft_IO.RX_OK_flag)
//    {
//        for (var = 0; var < UART_Soft_IO.RX_len; ++var)
//            UART_Soft_IO.TX(UART_Soft_IO.RX_data[var]);
//        UART_Soft_IO.Clear();
//    }
}

void LED_State(unsigned char sta)
{
    GPIO_WriteBit(GPIOE, GPIO_Pin_0, sta);
}
