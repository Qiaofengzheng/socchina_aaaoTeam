#include "system.h"
#include "debug.h"

#include "../General_Files/drivers/UART_Soft_IO.h"

void System_Init()
{
    //LED
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOD, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    GPIO_WriteBit(GPIOE, GPIO_Pin_0, Bit_SET);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_WriteBit(GPIOD, GPIO_Pin_2 | GPIO_Pin_3, Bit_SET);

    UART_Soft_IO.Init(9600);

    UART_Soft_IO.TXString("Hello WCH!\r\n");
}

void System_Loop()
{
    if(UART_Soft_IO.RX_OK_flag)
    {
        UART_Soft_IO.TX(UART_Soft_IO.RX_data);
        UART_Soft_IO.Clear();
    }
}
