#ifndef __NOKIA_5110_H_
#define __NOKIA_5110_H_

//============================���������á�=================================
#define PCD8544_WIDTH  84
#define PCD8544_HEIGHT 48

#define PCD8544_SIZE_ASCII_0806     8
#define PCD8544_SIZE_ASCII_1608     16

#define I8080_CMD  0          //д����
#define I8080_DATA 1          //д����

#define Inv_Display() PCD8544_Write_Byte(0x0d,PCD8544_CMD)

//============================��ͨѶ��ʽ��=================================
//#define SPI_HARD
#define SPI_SOFT

//============================�����Ŷ��塿=================================
#define SPI_PORT            GPIOB
#define SPI_SCLK_PIN        GPIO_Pin_3
#define SPI_MOSI_PIN        GPIO_Pin_5

#define I8080_DC_PORT       GPIOE
#define I8080_DC_PIN        GPIO_Pin_2

#define SPI_CS_PORT         GPIOA
#define SPI_CS_PIN          GPIO_Pin_15

#define SPI_SET_SCLK()      GPIO_WriteBit(SPI_PORT, SPI_SCLK_PIN, Bit_SET)
#define SPI_RESET_SCLK()    GPIO_WriteBit(SPI_PORT, SPI_SCLK_PIN, Bit_RESET)
#define SPI_SET_CS()        GPIO_WriteBit(SPI_CS_PORT, SPI_CS_PIN, Bit_SET)
#define SPI_RESET_CS()      GPIO_WriteBit(SPI_CS_PORT, SPI_CS_PIN, Bit_RESET)
#define I8080_DC(n)         GPIO_WriteBit(I8080_DC_PORT, I8080_DC_PIN, n)
#define SPI_MOSI(n)         GPIO_WriteBit(SPI_PORT, SPI_MOSI_PIN, n)

void PCD8544_Init(void);//��ʼ��
void PCD8544_Fill(unsigned char _data); 
void PCD8544_DrawPic(unsigned char x, unsigned char y, unsigned char width, unsigned char height, const unsigned char *_data);
void PCD8544_DrawDot(unsigned char x, unsigned char y);
void PCD8544_ShowStr(unsigned char x, unsigned char y, unsigned char *chr, unsigned char _size);
void PCD8544_ShowNum(unsigned char x, unsigned char y, signed long num, unsigned char len, unsigned char _size);
void PCD8544_ShowNumf(unsigned char x, unsigned char y, float num, unsigned char len, unsigned char _size);
void PCD8544_ShowCN(unsigned char x, unsigned char y, unsigned char *chr);

#endif
 
